import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { AdminHeader } from "@/components/admin/AdminHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus } from "lucide-react";
import { useState } from "react";

interface CategoryForm {
  name: string;
  slug: string;
}

const AdminCategoryNew = () => {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors } } = useForm<CategoryForm>();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  };

  const onSubmit = (data: CategoryForm) => {
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({ title: "Categoria criada com sucesso!" });
      navigate("/admin/categorias");
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-section-bg">
      <AdminHeader />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="mb-8">
            <Link to="/admin">
              <Button variant="outline" className="mb-4">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar ao Menu
              </Button>
            </Link>
            <h1 className="text-4xl font-bold text-white mb-2">
              Nova Categoria
            </h1>
            <p className="text-gray-400">
              Crie uma nova categoria para organizar os posts
            </p>
          </div>

          <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white">Nome da Categoria</Label>
                <Input
                  id="name"
                  placeholder="Ex: Segurança Cibernética"
                  className="bg-[#0f1729] border-gray-700 text-white"
                  {...register("name", { required: "Nome é obrigatório" })}
                />
                {errors.name && (
                  <p className="text-red-500 text-sm">{errors.name.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="slug" className="text-white">
                  Slug (opcional - será gerado automaticamente)
                </Label>
                <Input
                  id="slug"
                  placeholder="seguranca-cibernetica"
                  className="bg-[#0f1729] border-gray-700 text-white"
                  {...register("slug")}
                />
                <p className="text-sm text-gray-400">
                  O slug é usado na URL e será gerado automaticamente se deixado em branco
                </p>
              </div>

              <div className="flex gap-4">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-[#0d6efd] hover:bg-[#0b5ed7] text-white font-bold"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  {isSubmitting ? "Criando..." : "Criar Categoria"}
                </Button>
                
                <Link to="/admin">
                  <Button type="button" variant="outline">
                    Cancelar
                  </Button>
                </Link>
              </div>
            </form>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default AdminCategoryNew;
