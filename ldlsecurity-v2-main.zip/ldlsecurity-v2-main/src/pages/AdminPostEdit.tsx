import { Link, useNavigate, useParams } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { AdminHeader } from "@/components/admin/AdminHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Save } from "lucide-react";
import { useState, useEffect } from "react";
import RichTextEditor from "@/components/admin/RichTextEditor";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { usePosts } from "@/hooks/usePosts";
import { useCategories } from "@/hooks/useCategories";
import { useUploadFile } from "@/hooks/useUploadFile";
import { useToast } from "@/hooks/use-toast";

interface PostForm {
  title: string;
  excerpt: string;
  content: string;
  featuredImage: FileList | string;
  category: string;
  author: string;
  publishDate: string;
  readTime: string;
  metaTitle: string;
  metaDescription: string;
  published: boolean;
}

const AdminPostEdit = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { register, handleSubmit, setValue, control, reset, formState: { errors } } = useForm<PostForm>();
  const { toast } = useToast();
  const { updatePost, getPostBySlugForEdit } = usePosts();
  const { categories, loading: categoriesLoading } = useCategories();
  const { uploadFile, uploading } = useUploadFile();
  const [showSeoFields, setShowSeoFields] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageMode, setImageMode] = useState<'url' | 'upload'>('url');
  const [imageUrlValue, setImageUrlValue] = useState('');
  const [currentPostId, setCurrentPostId] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadPost = async () => {
      if (!slug) return;
      
      try {
        const post = await getPostBySlugForEdit(slug);
        if (post) {
          setCurrentPostId(post.id);
          
          // Set all form values including category
          setValue("title", post.title);
          setValue("excerpt", post.excerpt || '');
          setValue("content", post.content);
          setValue("author", post.author);
          setValue("publishDate", post.publish_date);
          setValue("readTime", post.read_time || '');
          setValue("metaTitle", post.meta_title || '');
          setValue("metaDescription", post.meta_description || '');
          setValue("published", post.published);
          setValue("category", post.category_id || '');
          
          if (post.featured_image) {
            setImageUrlValue(post.featured_image);
            setImageMode('url');
          }
          
          if (post.meta_title || post.meta_description) {
            setShowSeoFields(true);
          }
        } else {
          toast({
            title: "Post não encontrado",
            variant: "destructive",
          });
          navigate("/admin/posts");
        }
      } catch (error) {
        console.error("Error loading post:", error);
        toast({
          title: "Erro ao carregar post",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    loadPost();
  }, [slug, getPostBySlugForEdit, setValue, navigate, toast]);

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  };

  const onSubmit = async (data: PostForm) => {
    setIsSubmitting(true);
    
    try {
      let featuredImageUrl = imageUrlValue;

      // Handle new image upload
      if (imageMode === 'upload' && data.featuredImage instanceof FileList && data.featuredImage[0]) {
        const url = await uploadFile('blog-images', data.featuredImage[0]);
        if (url) featuredImageUrl = url;
      }

      const newSlug = generateSlug(data.title);

      await updatePost(currentPostId, {
        title: data.title,
        slug: newSlug,
        content: data.content,
        excerpt: data.excerpt || null,
        featured_image: featuredImageUrl || null,
        category_id: data.category || null,
        author: data.author,
        publish_date: data.publishDate,
        read_time: data.readTime || null,
        meta_title: data.metaTitle || null,
        meta_description: data.metaDescription || null,
        published: data.published,
      });

      toast({ title: "Post atualizado com sucesso!" });
      navigate("/admin/posts");
    } catch (error) {
      console.error("Error updating post:", error);
      toast({
        title: "Erro ao atualizar post",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-section-bg">
        <AdminHeader />
        <main className="flex-1 pt-24 pb-16 flex items-center justify-center">
          <p className="text-white">Carregando post...</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-section-bg">
      <AdminHeader />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="mb-8">
            <Link to="/admin/posts">
              <Button variant="outline" className="mb-4">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar aos Posts
              </Button>
            </Link>
            <h1 className="text-4xl font-bold text-white mb-2">
              Editar Post
            </h1>
            <p className="text-gray-400">
              Atualize as informações do post
            </p>
          </div>

          <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title" className="text-white">Título *</Label>
                <Input
                  id="title"
                  placeholder="Título do post"
                  className="bg-[#0f1729] border-gray-700 text-white"
                  {...register("title", { required: "Título é obrigatório" })}
                />
                {errors.title && (
                  <p className="text-red-500 text-sm">{errors.title.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="excerpt" className="text-white">Resumo</Label>
                <Input
                  id="excerpt"
                  placeholder="Breve resumo do post"
                  className="bg-[#0f1729] border-gray-700 text-white"
                  {...register("excerpt")}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="content" className="text-white">Conteúdo *</Label>
                <Controller
                  name="content"
                  control={control}
                  rules={{ required: "Conteúdo é obrigatório" }}
                  render={({ field }) => (
                    <RichTextEditor
                      content={field.value}
                      onChange={field.onChange}
                    />
                  )}
                />
                {errors.content && (
                  <p className="text-red-500 text-sm">{errors.content.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label className="text-white">Imagem Destacada</Label>
                <div className="flex gap-2 mb-2">
                  <Button
                    type="button"
                    size="sm"
                    variant={imageMode === 'upload' ? 'default' : 'outline'}
                    onClick={() => setImageMode('upload')}
                  >
                    Upload Nova
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={imageMode === 'url' ? 'default' : 'outline'}
                    onClick={() => setImageMode('url')}
                  >
                    URL
                  </Button>
                </div>

                {imageMode === 'upload' ? (
                  <Input
                    type="file"
                    accept="image/*"
                    className="bg-[#0f1729] border-gray-700 text-white"
                    {...register("featuredImage")}
                  />
                ) : (
                  <Input
                    placeholder="https://exemplo.com/imagem.jpg"
                    className="bg-[#0f1729] border-gray-700 text-white"
                    value={imageUrlValue}
                    onChange={(e) => {
                      setImageUrlValue(e.target.value);
                      setValue("featuredImage", e.target.value);
                    }}
                  />
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="category" className="text-white">Categoria</Label>
                  <Controller
                    name="category"
                    control={control}
                    render={({ field }) => (
                      <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger className="bg-[#0f1729] border-gray-700 text-white">
                          <SelectValue placeholder="Selecione uma categoria" />
                        </SelectTrigger>
                        <SelectContent>
                          {categoriesLoading ? (
                            <SelectItem value="loading" disabled>Carregando...</SelectItem>
                          ) : categories.length === 0 ? (
                            <SelectItem value="none" disabled>Nenhuma categoria</SelectItem>
                          ) : (
                            categories.map((cat) => (
                              <SelectItem key={cat.id} value={cat.id}>
                                {cat.name}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                    )}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="author" className="text-white">Autor *</Label>
                  <Input
                    id="author"
                    className="bg-[#0f1729] border-gray-700 text-white"
                    {...register("author", { required: "Autor é obrigatório" })}
                  />
                  {errors.author && (
                    <p className="text-red-500 text-sm">{errors.author.message}</p>
                  )}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="publishDate" className="text-white">Data de Publicação *</Label>
                  <Input
                    id="publishDate"
                    type="date"
                    className="bg-[#0f1729] border-gray-700 text-white"
                    {...register("publishDate", { required: "Data é obrigatória" })}
                  />
                  {errors.publishDate && (
                    <p className="text-red-500 text-sm">{errors.publishDate.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="readTime" className="text-white">Tempo de Leitura</Label>
                  <Input
                    id="readTime"
                    placeholder="5 min de leitura"
                    className="bg-[#0f1729] border-gray-700 text-white"
                    {...register("readTime")}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="published"
                  {...register("published")}
                  className="w-4 h-4"
                />
                <Label htmlFor="published" className="text-white cursor-pointer">
                  Publicado
                </Label>
              </div>

              <Button
                type="button"
                variant="outline"
                onClick={() => setShowSeoFields(!showSeoFields)}
                className="w-full"
              >
                {showSeoFields ? "Ocultar" : "Mostrar"} Campos SEO
              </Button>

              {showSeoFields && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="metaTitle" className="text-white">Meta Título</Label>
                    <Input
                      id="metaTitle"
                      placeholder="Título para SEO (máx. 60 caracteres)"
                      className="bg-[#0f1729] border-gray-700 text-white"
                      {...register("metaTitle")}
                      maxLength={60}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="metaDescription" className="text-white">Meta Descrição</Label>
                    <Input
                      id="metaDescription"
                      placeholder="Descrição para SEO (máx. 160 caracteres)"
                      className="bg-[#0f1729] border-gray-700 text-white"
                      {...register("metaDescription")}
                      maxLength={160}
                    />
                  </div>
                </>
              )}

              <div className="flex gap-4">
                <Button
                  type="submit"
                  disabled={isSubmitting || uploading}
                  className="bg-[#0d6efd] hover:bg-[#0b5ed7] text-white font-bold flex-1"
                >
                  <Save className="mr-2 h-4 w-4" />
                  {isSubmitting ? "Salvando..." : "Salvar Alterações"}
                </Button>
                <Link to="/admin/posts">
                  <Button type="button" variant="outline">
                    Cancelar
                  </Button>
                </Link>
              </div>
            </form>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default AdminPostEdit;
