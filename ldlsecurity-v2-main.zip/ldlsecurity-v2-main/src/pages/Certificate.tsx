import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShieldCheck, AlertCircle, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import certificadoExemplo from "@/assets/certificado-exemplo.webp";
import { useCertificates } from "@/hooks/useCertificates";
import { Card } from "@/components/ui/card";

const Certificate = () => {
  const [certificateKey, setCertificateKey] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<any>(null);
  const { validateCertificate } = useCertificates();

  const formatCertificateKey = (value: string) => {
    // Remove tudo que não é número
    const numbers = value.replace(/\D/g, '');
    
    // Limita a 9 dígitos
    const limited = numbers.slice(0, 9);
    
    // Adiciona os traços: 999-999-999
    if (limited.length <= 3) return limited;
    if (limited.length <= 6) return `${limited.slice(0, 3)}-${limited.slice(3)}`;
    return `${limited.slice(0, 3)}-${limited.slice(3, 6)}-${limited.slice(6)}`;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCertificateKey(e.target.value);
    setCertificateKey(formatted);
  };

  const handleValidation = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!certificateKey.trim()) {
      toast.error("Por favor, insira a chave do certificado");
      return;
    }

    setIsValidating(true);
    setValidationResult(null);
    
    try {
      // Remove traços antes de validar
      const cleanKey = certificateKey.replace(/-/g, '');
      const result = await validateCertificate(cleanKey);
      
      if (result) {
        setValidationResult(result);
        toast.success("Certificado válido!");
      } else {
        toast.error("Certificado não encontrado");
        setValidationResult({ notFound: true });
      }
    } catch (error) {
      console.error("Error validating certificate:", error);
      toast.error("Erro ao validar certificado");
    } finally {
      setIsValidating(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-24 bg-gradient-to-b from-[#0a0913] to-[#3c33ab]">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/20 mb-8">
              <ShieldCheck className="w-10 h-10 text-primary" />
            </div>

            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Validador de Certificado
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-12">
              Insira a chave única do seu certificado para verificar sua autenticidade e visualizar os detalhes.
            </p>

            {/* Validation Form */}
            <div className="bg-[#1a1f2e]/50 backdrop-blur-sm border border-gray-700/30 rounded-2xl p-12 mb-8">
              <h2 className="text-3xl font-bold text-white mb-8">
                Informe a Chave
              </h2>
              
              <form onSubmit={handleValidation} className="flex gap-4 max-w-4xl mx-auto">
                <Input
                  type="text"
                  placeholder="999-999-999"
                  value={certificateKey}
                  onChange={handleInputChange}
                  maxLength={11}
                  className="flex-1 bg-[#1a1d2e] border-[#2a2d3e] text-white placeholder:text-gray-500 text-lg h-14 rounded-lg"
                />
                <Button 
                  type="submit" 
                  size="lg" 
                  className="bg-[#0d6efd] hover:bg-[#0b5ed7] text-white font-semibold px-8 h-14 rounded-lg"
                  disabled={isValidating}
                >
                  {isValidating ? "Validando..." : "Validar Certificado"}
                </Button>
              </form>
              
              <p className="text-sm text-gray-400 mt-4">
                A chave do certificado está localizada no rodapé do documento
              </p>
            </div>

            {/* Validation Result */}
            {validationResult && (
              <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-8 mb-8 text-left">
                {validationResult.notFound ? (
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
                      <XCircle className="w-6 h-6 text-red-500" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-2">
                        Certificado Não Encontrado
                      </h3>
                      <p className="text-gray-400">
                        A chave informada não corresponde a nenhum certificado em nossa base de dados.
                        Verifique se digitou corretamente ou entre em contato conosco.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-start gap-4 mb-6">
                      <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="w-6 h-6 text-green-500" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold text-white mb-2">
                          Certificado Válido
                        </h3>
                        <p className="text-gray-400">
                          Este certificado foi emitido pela LDL Security e é autêntico.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-4 border-t border-gray-700 pt-6">
                      <div>
                        <span className="text-sm text-gray-400 block mb-1">Empresa</span>
                        <span className="text-white font-medium">{validationResult.company_name}</span>
                      </div>
                      <div>
                        <span className="text-sm text-gray-400 block mb-1">CNPJ</span>
                        <span className="text-white font-medium">{validationResult.cnpj}</span>
                      </div>
                      {validationResult.domains && validationResult.domains.length > 0 && (
                        <div>
                          <span className="text-sm text-gray-400 block mb-1">Domínios</span>
                          <div className="space-y-1">
                            {validationResult.domains.map((domain: string, index: number) => (
                              <div key={index} className="text-white font-medium">
                                • {domain}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      <div>
                        <span className="text-sm text-gray-400 block mb-1">Chave de Validação</span>
                        <span className="text-[#60a5fa] font-mono">{validationResult.validation_key}</span>
                      </div>
                      <div>
                        <span className="text-sm text-gray-400 block mb-1">Data de Emissão</span>
                        <span className="text-white font-medium">
                          {new Date(validationResult.created_at).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                      <div className="pt-4">
                        <Button
                          asChild
                          className="bg-[#0d6efd] hover:bg-[#0b5ed7]"
                        >
                          <a href={validationResult.document_url} target="_blank" rel="noopener noreferrer">
                            Visualizar Certificado
                          </a>
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </Card>
            )}

            {/* Info Box */}
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 flex gap-4 text-left mb-16">
              <AlertCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-foreground mb-2">
                  Por que validar?
                </h3>
                <p className="text-sm text-muted-foreground">
                  A validação do certificado garante a autenticidade do documento emitido pela LDL Security, 
                  protegendo contra falsificações e garantindo que o trabalho foi realmente executado e 
                  certificado pela nossa equipe.
                </p>
              </div>
            </div>

            {/* Certificate Example Section */}
            <div className="mt-16">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">
                Exemplo de Certificado
              </h2>
              
              <div className="bg-card/30 backdrop-blur-sm border border-border rounded-lg p-4 md:p-8">
                <img 
                  src={certificadoExemplo} 
                  alt="Exemplo de Certificado LDL Security"
                  className="w-full rounded-lg shadow-2xl"
                />
                
                <div className="mt-6 text-left space-y-3">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-semibold text-foreground">Informações incluídas:</span>
                  </p>
                  <ul className="text-sm text-muted-foreground space-y-2 ml-4">
                    <li>• Nome da empresa ou cliente</li>
                    <li>• Tipo de serviço executado (Pentest, Auditoria, etc.)</li>
                    <li>• Data de realização do trabalho</li>
                    <li>• Chave única de validação</li>
                    <li>• Assinatura digital da LDL Security</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Certificate;
