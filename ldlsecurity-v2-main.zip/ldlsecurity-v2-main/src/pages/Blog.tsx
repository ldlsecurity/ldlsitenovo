import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Calendar, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePosts } from "@/hooks/usePosts";
import { useCategories } from "@/hooks/useCategories";

const Blog = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const { posts, loading: postsLoading } = usePosts();
  const { categories, loading: categoriesLoading } = useCategories();

  // Filter published posts
  const publishedPosts = useMemo(() => {
    return posts.filter(post => post.published);
  }, [posts]);

  // Filter posts by category
  const filteredPosts = useMemo(() => {
    if (selectedCategory === "all") {
      return publishedPosts;
    }
    return publishedPosts.filter(post => post.category_id === selectedCategory);
  }, [selectedCategory, publishedPosts]);

  const getCategoryName = (categoryId: string | null) => {
    if (!categoryId) return [];
    const category = categories.find(c => c.id === categoryId);
    return category ? [category.name] : [];
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-24 bg-gradient-to-b from-[#0a0913] to-[#3c33ab]">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Blog de Cibersegurança
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground">
              Nosso blog sobre tecnologia, segurança e muito mais.
            </p>
          </div>
        </div>
      </section>

      {/* Category Filters */}
      <section className="py-8 bg-[#0f1729] border-b border-border">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="flex flex-wrap gap-3 justify-center">
            <Button
              variant={selectedCategory === "all" ? "default" : "outline"}
              onClick={() => setSelectedCategory("all")}
            >
              Todas
            </Button>
            {categoriesLoading ? (
              <Button variant="outline" disabled>Carregando...</Button>
            ) : (
              categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.id)}
                  className="capitalize"
                >
                  {category.name}
                </Button>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-16 md:py-24 bg-[#0f1729]">
        <div className="container mx-auto px-6 lg:px-8">
          {postsLoading ? (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">
                Carregando posts...
              </p>
            </div>
          ) : filteredPosts.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">
                Nenhum artigo encontrado nesta categoria.
              </p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post) => (
              <Link key={post.id} to={`/blog/${post.slug}`}>
                <article 
                  className="bg-card/50 backdrop-blur-sm border border-border rounded-lg overflow-hidden hover:shadow-xl transition-all hover:-translate-y-1 cursor-pointer group"
                >
                {post.featured_image && (
                  <div className="relative overflow-hidden">
                    <img 
                      src={post.featured_image}
                      alt={post.title}
                      className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                )}
                
                <div className="p-6">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{new Date(post.publish_date).toLocaleDateString('pt-BR')}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      <span>{post.author}</span>
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-foreground mb-3 line-clamp-2 group-hover:text-primary transition-colors">
                    {post.title}
                  </h3>
                  
                  {post.excerpt && (
                    <p className="text-muted-foreground mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                  )}

                  <div className="flex flex-wrap gap-2">
                    {getCategoryName(post.category_id).map((tag) => (
                      <span 
                        key={tag}
                        className="px-3 py-1 bg-primary/20 text-primary text-xs rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
              </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Blog;
