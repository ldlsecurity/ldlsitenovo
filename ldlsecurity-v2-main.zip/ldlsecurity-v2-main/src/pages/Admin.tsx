import { Link } from "react-router-dom";
import { AdminHeader } from "@/components/admin/AdminHeader";
import { Card } from "@/components/ui/card";
import { FileText, FolderOpen, ScrollText, Users, KeyRound } from "lucide-react";

const Admin = () => {
  const menuItems = [
    {
      title: "Certificados",
      icon: FileText,
      link: "/admin/certificados",
      description: "Gerenciar certificados",
      color: "text-[#60a5fa]",
      bgColor: "bg-[#0d6efd]/20",
      hoverBg: "group-hover:bg-[#0d6efd]/30",
    },
    {
      title: "Posts",
      icon: ScrollText,
      link: "/admin/posts",
      description: "Gerenciar posts do blog",
      color: "text-green-400",
      bgColor: "bg-green-500/20",
      hoverBg: "group-hover:bg-green-500/30",
    },
    {
      title: "Categorias",
      icon: FolderOpen,
      link: "/admin/categorias",
      description: "Gerenciar categorias",
      color: "text-yellow-400",
      bgColor: "bg-yellow-500/20",
      hoverBg: "group-hover:bg-yellow-500/30",
    },
    {
      title: "Usuários",
      icon: Users,
      link: "/admin/usuarios",
      description: "Gerenciar permissões",
      color: "text-purple-400",
      bgColor: "bg-purple-500/20",
      hoverBg: "group-hover:bg-purple-500/30",
    },
    {
      title: "Alterar Senha",
      icon: KeyRound,
      link: "/admin/alterar-senha",
      description: "Alterar sua senha",
      color: "text-orange-400",
      bgColor: "bg-orange-500/20",
      hoverBg: "group-hover:bg-orange-500/30",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-section-bg">
      <AdminHeader />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h1 className="text-4xl font-bold text-white mb-4">
              Painel Administrativo
            </h1>
            <p className="text-gray-400 text-lg">
              Escolha uma opção para gerenciar o conteúdo
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {menuItems.map((item) => (
              <Link key={item.link} to={item.link}>
                <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6 hover:bg-[#1a1f2e]/80 transition-all hover:border-[#0d6efd]/50 cursor-pointer group">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className={`w-16 h-16 ${item.bgColor} rounded-full flex items-center justify-center ${item.hoverBg} transition-all`}>
                      <item.icon className={`w-8 h-8 ${item.color}`} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white mb-2">
                        {item.title}
                      </h3>
                      <p className="text-gray-400 text-sm">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Admin;
