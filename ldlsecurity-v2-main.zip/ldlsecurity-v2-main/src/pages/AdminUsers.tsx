import { useState } from "react";
import { Link } from "react-router-dom";
import { AdminHeader } from "@/components/admin/AdminHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Shield, ShieldOff, UserPlus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAdminUsers } from "@/hooks/useAdminUsers";
import { Badge } from "@/components/ui/badge";

const AdminUsers = () => {
  const { users, loading, toggleAdminRole, createUser, deleteUser } = useAdminUsers();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreating(true);

    const { error } = await createUser(email, password, fullName, isAdmin);

    if (!error) {
      setOpen(false);
      setEmail('');
      setPassword('');
      setFullName('');
      setIsAdmin(false);
    }

    setIsCreating(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-section-bg">
      <AdminHeader />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <Link to="/admin">
              <Button variant="outline" className="mb-4">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar ao Menu
              </Button>
            </Link>
            
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">
                  Gerenciar Usuários
                </h1>
                <p className="text-gray-400">
                  Gerencie permissões de administrador
                </p>
              </div>
              
              <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-[#0d6efd] hover:bg-[#0b5ed7]">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Adicionar Usuário
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-[#1a1f2e] border-gray-700">
                  <form onSubmit={handleCreateUser}>
                    <DialogHeader>
                      <DialogTitle className="text-white">Adicionar Novo Usuário</DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Crie um novo usuário e defina suas permissões
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-white">
                          Email
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="usuario@exemplo.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="bg-[#0f1729] border-gray-700 text-white"
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="fullName" className="text-white">
                          Nome Completo
                        </Label>
                        <Input
                          id="fullName"
                          type="text"
                          placeholder="João Silva"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          className="bg-[#0f1729] border-gray-700 text-white"
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="password" className="text-white">
                          Senha
                        </Label>
                        <Input
                          id="password"
                          type="password"
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="bg-[#0f1729] border-gray-700 text-white"
                          required
                          minLength={6}
                        />
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="isAdmin"
                          checked={isAdmin}
                          onCheckedChange={(checked) => setIsAdmin(checked as boolean)}
                        />
                        <Label 
                          htmlFor="isAdmin" 
                          className="text-white cursor-pointer"
                        >
                          Conceder permissões de administrador
                        </Label>
                      </div>
                    </div>
                    
                    <DialogFooter>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setOpen(false)}
                        disabled={isCreating}
                      >
                        Cancelar
                      </Button>
                      <Button
                        type="submit"
                        disabled={isCreating}
                        className="bg-[#0d6efd] hover:bg-[#0b5ed7]"
                      >
                        {isCreating ? 'Criando...' : 'Criar Usuário'}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6">
            {loading ? (
              <div className="text-center py-16 text-gray-400">
                Carregando usuários...
              </div>
            ) : users.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-gray-400">
                  Nenhum usuário cadastrado
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-white">Email</TableHead>
                    <TableHead className="text-white">Nome</TableHead>
                    <TableHead className="text-white">Cadastro</TableHead>
                    <TableHead className="text-white">Permissão</TableHead>
                    <TableHead className="text-white">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id} className="border-gray-700">
                      <TableCell className="text-gray-300 font-medium">
                        {user.email}
                      </TableCell>
                      <TableCell className="text-gray-300">
                        {user.full_name || '-'}
                      </TableCell>
                      <TableCell className="text-gray-300">
                        {new Date(user.created_at).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell>
                        {user.is_admin ? (
                          <Badge className="bg-green-500/20 text-green-400">
                            Admin
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-gray-400">
                            Usuário
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant={user.is_admin ? "destructive" : "default"}
                            onClick={() => toggleAdminRole(user.id, user.is_admin)}
                            className={!user.is_admin ? "bg-[#0d6efd] hover:bg-[#0b5ed7]" : ""}
                          >
                            {user.is_admin ? (
                              <>
                                <ShieldOff className="h-4 w-4 mr-2" />
                                Remover Admin
                              </>
                            ) : (
                              <>
                                <Shield className="h-4 w-4 mr-2" />
                                Tornar Admin
                              </>
                            )}
                          </Button>
                          
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                size="sm"
                                variant="destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-[#1a1f2e] border-gray-700">
                              <AlertDialogHeader>
                                <AlertDialogTitle className="text-white">
                                  Confirmar exclusão
                                </AlertDialogTitle>
                                <AlertDialogDescription className="text-gray-400">
                                  Tem certeza que deseja deletar o usuário <strong>{user.email}</strong>? 
                                  Esta ação não pode ser desfeita e todos os dados do usuário serão permanentemente removidos.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel className="bg-[#0f1729] border-gray-700 text-white hover:bg-[#1a1f2e]">
                                  Cancelar
                                </AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => deleteUser(user.id)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  Deletar Usuário
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Card>
        </div>
      </main>
    </div>
  );
};

export default AdminUsers;
