import Header from "@/components/Header";
import Footer from "@/components/Footer";
import leoImage from "@/assets/team/leo.jpg";
import igorImage from "@/assets/team/igor.jpg";
import guilhermeImage from "@/assets/team/guilherme.jpg";
import renatoImage from "@/assets/team/renato.jpg";
import eventoImage from "@/assets/team/evento.jpeg";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-24 bg-gradient-to-b from-[#0a0913] to-[#3c33ab]">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <p className="text-primary text-sm font-semibold uppercase tracking-wider mb-4">
              Sobre a LDL Security
            </p>
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Soluções avançadas em Segurança Cibernética
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              A LDL Security é uma empresa brasileira especializada em testes de penetração e serviços de segurança cibernética.
              Nossa equipe de especialistas altamente qualificados utiliza metodologias avançadas para identificar vulnerabilidades
              e fortalecer a postura de segurança de nossos clientes, protegendo seus ativos digitais contra ameaças emergentes.
            </p>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mt-4">
              Acreditamos que a segurança digital é um direito de todas as empresas. Por isso, oferecemos soluções acessíveis, 
              com foco em prevenção e conscientização.
            </p>
          </div>
        </div>
      </section>

      {/* Event Image Section */}
      <section className="py-16 bg-[#0f1729]">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="max-w-5xl mx-auto md:max-w-2xl">
            <img 
              src={eventoImage} 
              alt="Leonardo Duarte Leite (CEO) da LDL Security com Ricardo Longatto (CEO) da Desec Security durante evento de segurança cibernética"
              className="w-full rounded-lg shadow-2xl"
            />
            <p className="text-center text-sm text-muted-foreground mt-4">
              Leonardo Duarte Leite (CEO) da LDL Security com Ricardo Longatto (CEO) da Desec Security durante evento de segurança cibernética
            </p>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-[#0a0913] to-[#3c33ab]">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Nossa Equipe
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Conheça alguns de nossos especialistas que lideram nossa empresa com expertise técnica e visão estratégica
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* Leonardo */}
            <div className="bg-card/50 backdrop-blur-sm border border-border rounded-lg p-8 hover:shadow-xl transition-shadow text-center">
              <div className="mb-6 flex justify-center">
                <img 
                  src={leoImage} 
                  alt="Leonardo Duarte Leite"
                  className="w-40 h-40 rounded-full object-cover border-4 border-primary/20"
                />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">
                Leonardo Duarte Leite
              </h3>
              <p className="text-primary font-semibold mb-4">
                CEO & Fundador
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Leonardo Duarte Leite, CEO & Fundador da LDL Security. Com 5 anos de experiência em testes de intrusão 
                e defesa digital, lidera projetos de pentest e resposta a incidentes. Certificações em segurança e 
                formação em cibersegurança (PUCRS, Cisco, UniSenac).
              </p>
            </div>

            {/* Igor */}
            <div className="bg-card/50 backdrop-blur-sm border border-border rounded-lg p-8 hover:shadow-xl transition-shadow text-center">
              <div className="mb-6 flex justify-center">
                <img 
                  src={igorImage} 
                  alt="Igor de Jesus"
                  className="w-40 h-40 rounded-full object-cover border-4 border-primary/20"
                />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">
                Igor de Jesus
              </h3>
              <p className="text-primary font-semibold mb-4">
                CTO - Chief Technology Officer
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Igor de Jesus é CTO da LDL Security, responsável pela operação diária e execução tática de projetos 
                de cibersegurança. Possui ampla experiência em testes de intrusão, análise de código seguro e 
                implantação de defesas escaláveis para clientes corporativos.
              </p>
            </div>

            {/* Guilherme */}
            <div className="bg-card/50 backdrop-blur-sm border border-border rounded-lg p-8 hover:shadow-xl transition-shadow text-center">
              <div className="mb-6 flex justify-center">
                <img 
                  src={guilhermeImage} 
                  alt="Guilherme Albuquerque"
                  className="w-40 h-40 rounded-full object-cover border-4 border-primary/20"
                />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">
                Guilherme Albuquerque
              </h3>
              <p className="text-primary font-semibold mb-4">
                Pentester & Desenvolvedor
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Guilherme Albuquerque é especialista em testes de penetração e desenvolvimento de ferramentas de segurança. 
                Com expertise em análise de vulnerabilidades e código seguro, contribui ativamente para o fortalecimento 
                da postura de segurança dos clientes da LDL Security.
              </p>
            </div>

            {/* Renato */}
            <div className="bg-card/50 backdrop-blur-sm border border-border rounded-lg p-8 hover:shadow-xl transition-shadow text-center">
              <div className="mb-6 flex justify-center">
                <img 
                  src={renatoImage} 
                  alt="Renato Trindade"
                  className="w-40 h-40 rounded-full object-cover border-4 border-primary/20"
                />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">
                Renato Trindade
              </h3>
              <p className="text-primary font-semibold mb-4">
                Pentester & Analista de Segurança
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Renato Trindade é pentester e analista de segurança especializado em identificação de vulnerabilidades 
                e avaliação de riscos. Sua experiência técnica e abordagem metódica fortalecem a qualidade dos serviços 
                de segurança oferecidos pela LDL Security.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;
