import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Platform from "@/components/Platform";
import VideoSection from "@/components/VideoSection";
import Stats from "@/components/Stats";
import Impact from "@/components/Impact";
import Process from "@/components/Process";
import Services from "@/components/Services";
import Testimonials from "@/components/Testimonials";
import TrustedBy from "@/components/TrustedBy";
import FAQ from "@/components/FAQ";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";
const Index = () => {
  const location = useLocation();
  useEffect(() => {
    if (location.state?.scrollTo) {
      // Pequeno delay para garantir que o DOM foi renderizado
      setTimeout(() => {
        const element = document.getElementById(location.state.scrollTo);
        if (element) {
          element.scrollIntoView({
            behavior: 'smooth'
          });
        }
      }, 100);
    }
  }, [location]);
  return <div className="min-h-screen bg-background">
      <Header />
      <Hero />
      <Platform />
      
      <Testimonials />
      <div className="bg-gradient-to-r from-[hsl(var(--bg-dark-blue))] to-[hsl(var(--bg-purple-blue))]">
        <Process />
        <Impact />
      </div>
      <Stats />
      <Services />
      <FAQ />
      <CTA />
      <Footer />
    </div>;
};
export default Index;