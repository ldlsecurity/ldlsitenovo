import { useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Terms = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-32 pb-16">
        <div className="container mx-auto px-6 lg:px-8 max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-8">
            Termos e Condições
          </h1>
          
          <p className="text-muted-foreground mb-8 italic">Última atualização: 06 de Janeiro de 2023</p>
          
          <p className="text-muted-foreground mb-8">
            Por favor, leia estes termos e condições cuidadosamente antes de usar Nosso Serviço.
          </p>
          
          <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Interpretação e Definições</h2>
              
              <h3 className="text-xl font-semibold text-foreground mb-3">Interpretação</h3>
              <p>
                As palavras cuja letra inicial está em maiúscula têm significados definidos sob as seguintes condições. As seguintes definições terão o mesmo significado independentemente de aparecerem no singular ou no plural.
              </p>
              
              <h3 className="text-xl font-semibold text-foreground mb-3 mt-6">Definições</h3>
              <p>Para os fins destes Termos e Condições:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Afiliada</strong> significa uma entidade que controla, é controlada por ou está sob controle comum com uma parte, onde "controle" significa propriedade de 50% ou mais das ações, participação acionária ou outros títulos com direito a voto para eleição de diretores ou outra autoridade administrativa.</li>
                <li><strong>País</strong> refere-se a: Califórnia, Estados Unidos</li>
                <li><strong>Empresa</strong> (referida como "a Empresa", "Nós", "Nos" ou "Nossa" neste Acordo) refere-se à AstroWind LLC, 1 Cupertino, CA 95014.</li>
                <li><strong>Dispositivo</strong> significa qualquer dispositivo que pode acessar o Serviço, como um computador, um celular ou um tablet digital.</li>
                <li><strong>Serviço</strong> refere-se ao Site.</li>
                <li><strong>Termos e Condições</strong> (também referidos como "Termos") significam estes Termos e Condições que formam o acordo completo entre Você e a Empresa em relação ao uso do Serviço. Este acordo de Termos e Condições é uma Demonstração.</li>
                <li><strong>Serviço de Mídia Social de Terceiros</strong> significa quaisquer serviços ou conteúdo (incluindo dados, informações, produtos ou serviços) fornecidos por um terceiro que podem ser exibidos, incluídos ou disponibilizados pelo Serviço.</li>
                <li><strong>Site</strong> refere-se ao AstroWind, acessível em https://astrowind.vercel.app</li>
                <li><strong>Você</strong> significa o indivíduo acessando ou usando o Serviço, ou a empresa ou outra entidade legal em nome da qual tal indivíduo está acessando ou usando o Serviço, conforme aplicável.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Reconhecimento</h2>
              <p>
                Estes são os Termos e Condições que regem o uso deste Serviço e o acordo que opera entre Você e a Empresa. Estes Termos e Condições estabelecem os direitos e obrigações de todos os usuários em relação ao uso do Serviço.
              </p>
              <p>
                Seu acesso e uso do Serviço está condicionado à Sua aceitação e conformidade com estes Termos e Condições. Estes Termos e Condições se aplicam a todos os visitantes, usuários e outros que acessam ou usam o Serviço.
              </p>
              <p>
                Ao acessar ou usar o Serviço, Você concorda em estar vinculado a estes Termos e Condições. Se Você discordar de qualquer parte destes Termos e Condições, então Você não pode acessar o Serviço.
              </p>
              <p>
                Você declara que tem mais de 18 anos. A Empresa não permite que menores de 18 anos usem o Serviço.
              </p>
              <p>
                Seu acesso e uso do Serviço também está condicionado à Sua aceitação e conformidade com a Política de Privacidade da Empresa. Nossa Política de Privacidade descreve Nossas políticas e procedimentos sobre a coleta, uso e divulgação de Suas informações pessoais quando Você usa o Aplicativo ou o Site e informa sobre Seus direitos de privacidade e como a lei protege Você. Por favor, leia Nossa Política de Privacidade cuidadosamente antes de usar Nosso Serviço.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Links para Outros Sites</h2>
              <p>
                Nosso Serviço pode conter links para sites ou serviços de terceiros que não são de propriedade ou controlados pela Empresa.
              </p>
              <p>
                A Empresa não tem controle sobre e não assume responsabilidade pelo conteúdo, políticas de privacidade ou práticas de quaisquer sites ou serviços de terceiros. Você reconhece e concorda que a Empresa não será responsável ou responsabilizada, direta ou indiretamente, por qualquer dano ou perda causada ou alegadamente causada por ou em conexão com o uso ou confiança em qualquer conteúdo, bens ou serviços disponíveis em ou através de tais sites ou serviços.
              </p>
              <p>
                Recomendamos fortemente que Você leia os termos e condições e políticas de privacidade de quaisquer sites ou serviços de terceiros que Você visitar.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Rescisão</h2>
              <p>
                Podemos encerrar ou suspender Seu acesso imediatamente, sem aviso prévio ou responsabilidade, por qualquer motivo, incluindo, sem limitação, se Você violar estes Termos e Condições.
              </p>
              <p>
                Após a rescisão, Seu direito de usar o Serviço cessará imediatamente.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Limitação de Responsabilidade</h2>
              <p>
                Não obstante quaisquer danos que Você possa incorrer, a responsabilidade total da Empresa e de qualquer um de seus fornecedores sob qualquer disposição destes Termos e Sua exclusiva compensação por todo o precedente será limitada ao valor realmente pago por Você através do Serviço ou 100 USD se Você não comprou nada através do Serviço.
              </p>
              <p>
                Na extensão máxima permitida pela lei aplicável, em nenhum caso a Empresa ou seus fornecedores serão responsáveis por quaisquer danos especiais, incidentais, indiretos ou consequenciais (incluindo, mas não se limitando a, danos por perda de lucros, perda de dados ou outras informações, por interrupção de negócios, por danos pessoais, perda de privacidade decorrente de ou de alguma forma relacionada ao uso ou incapacidade de usar o Serviço, software e/ou hardware de terceiros usado com o Serviço, ou de outra forma em conexão com qualquer disposição destes Termos), mesmo se a Empresa ou qualquer fornecedor tiver sido avisado da possibilidade de tais danos e mesmo se o recurso falhar em seu propósito essencial.
              </p>
              <p>
                Alguns estados não permitem a exclusão de garantias implícitas ou limitação de responsabilidade por danos incidentais ou consequenciais, o que significa que algumas das limitações acima podem não se aplicar. Nesses estados, a responsabilidade de cada parte será limitada na maior extensão permitida por lei.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Isenção de Responsabilidade "COMO ESTÁ" e "COMO DISPONÍVEL"</h2>
              <p>
                O Serviço é fornecido a Você "COMO ESTÁ" e "COMO DISPONÍVEL" e com todas as falhas e defeitos sem garantia de qualquer tipo. Na extensão máxima permitida pela lei aplicável, a Empresa, em seu próprio nome e em nome de suas Afiliadas e seus respectivos licenciadores e prestadores de serviços, expressamente se isenta de todas as garantias, sejam expressas, implícitas, estatutárias ou de outra forma, com respeito ao Serviço, incluindo todas as garantias implícitas de comercialização, adequação a um propósito específico, título e não violação, e garantias que possam surgir do curso de negociação, curso de desempenho, uso ou prática comercial.
              </p>
              <p>
                Sem limitar o precedente, nem a Empresa nem qualquer provedor da empresa faz qualquer representação ou garantia de qualquer tipo, expressa ou implícita: (i) quanto à operação ou disponibilidade do Serviço, ou as informações, conteúdo e materiais ou produtos incluídos nele; (ii) que o Serviço será ininterrupto ou livre de erros; (iii) quanto à precisão, confiabilidade ou atualidade de qualquer informação ou conteúdo fornecido através do Serviço; ou (iv) que o Serviço, seus servidores, o conteúdo ou e-mails enviados de ou em nome da Empresa estão livres de vírus, scripts, cavalos de troia, worms, malware, timebombs ou outros componentes prejudiciais.
              </p>
              <p>
                Algumas jurisdições não permitem a exclusão de certos tipos de garantias ou limitações sobre direitos estatutários aplicáveis de um consumidor, então algumas ou todas as exclusões e limitações acima podem não se aplicar a Você. Mas em tal caso, as exclusões e limitações estabelecidas nesta seção serão aplicadas na maior extensão executável sob a lei aplicável.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Lei Aplicável</h2>
              <p>
                As leis do País, excluindo seus conflitos de regras legais, regerão estes Termos e Seu uso do Serviço. Seu uso do Aplicativo também pode estar sujeito a outras leis locais, estaduais, nacionais ou internacionais.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Resolução de Disputas</h2>
              <p>
                Se Você tiver qualquer preocupação ou disputa sobre o Serviço, Você concorda em primeiro tentar resolver a disputa informalmente contatando a Empresa.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Para Usuários da União Europeia (UE)</h2>
              <p>
                Se Você é um consumidor da União Europeia, você se beneficiará de quaisquer disposições obrigatórias da lei do país em que reside.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Conformidade Legal dos Estados Unidos</h2>
              <p>
                Você declara e garante que (i) Você não está localizado em um país que está sujeito ao embargo do governo dos Estados Unidos, ou que foi designado pelo governo dos Estados Unidos como um país "apoiador de terroristas", e (ii) Você não está listado em qualquer lista do governo dos Estados Unidos de partes proibidas ou restritas.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Divisibilidade e Renúncia</h2>
              
              <h3 className="text-xl font-semibold text-foreground mb-3">Divisibilidade</h3>
              <p>
                Se qualquer disposição destes Termos for considerada inexequível ou inválida, tal disposição será alterada e interpretada para cumprir os objetivos de tal disposição na maior extensão possível sob a lei aplicável e as disposições restantes continuarão em pleno vigor e efeito.
              </p>
              
              <h3 className="text-xl font-semibold text-foreground mb-3 mt-4">Renúncia</h3>
              <p>
                Exceto conforme previsto aqui, a falha em exercer um direito ou exigir o cumprimento de uma obrigação sob estes Termos não afetará a capacidade de uma parte de exercer tal direito ou exigir tal cumprimento em qualquer momento posterior, nem a renúncia de uma violação constituirá uma renúncia de qualquer violação subsequente.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Interpretação de Tradução</h2>
              <p>
                Estes Termos e Condições podem ter sido traduzidos se os disponibilizamos a Você em nosso Serviço. Você concorda que o texto original em inglês prevalecerá no caso de uma disputa.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Alterações a Estes Termos e Condições</h2>
              <p>
                Reservamo-nos o direito, a Nosso exclusivo critério, de modificar ou substituir estes Termos a qualquer momento. Se uma revisão for material, faremos esforços razoáveis para fornecer pelo menos 30 dias de aviso antes que quaisquer novos termos entrem em vigor. O que constitui uma alteração material será determinado a Nosso exclusivo critério.
              </p>
              <p>
                Ao continuar a acessar ou usar Nosso Serviço após essas revisões se tornarem efetivas, Você concorda em estar vinculado aos termos revisados. Se Você não concordar com os novos termos, no todo ou em parte, por favor pare de usar o site e o Serviço.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Contate-Nos</h2>
              <p>
                Se você tiver alguma dúvida sobre estes Termos e Condições, Você pode nos contatar:
              </p>
              <ul className="list-none space-y-2">
                <li>Por e-mail: contato@ldlsecurity.com</li>
              </ul>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Terms;
