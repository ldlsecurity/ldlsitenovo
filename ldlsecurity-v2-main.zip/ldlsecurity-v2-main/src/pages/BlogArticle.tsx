import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Calendar, User, Clock } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import NotFound from "./NotFound";
import { usePosts } from "@/hooks/usePosts";
import { useEffect, useState } from "react";

const BlogArticle = () => {
  const { slug } = useParams();
  const { getPostBySlug } = usePosts();
  const [post, setPost] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      if (!slug) return;
      setLoading(true);
      const data = await getPostBySlug(slug);
      setPost(data);
      setLoading(false);
    };

    fetchPost();
  }, [slug]);

  // Update meta tags when post loads
  useEffect(() => {
    if (post) {
      // Set page title
      document.title = post.meta_title || post.title;

      // Update meta description
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute('content', post.meta_description || post.excerpt || '');
      } else {
        const meta = document.createElement('meta');
        meta.name = 'description';
        meta.content = post.meta_description || post.excerpt || '';
        document.head.appendChild(meta);
      }

      // Update Open Graph tags
      const updateOrCreateMetaTag = (property: string, content: string) => {
        let tag = document.querySelector(`meta[property="${property}"]`);
        if (tag) {
          tag.setAttribute('content', content);
        } else {
          tag = document.createElement('meta');
          tag.setAttribute('property', property);
          tag.setAttribute('content', content);
          document.head.appendChild(tag);
        }
      };

      updateOrCreateMetaTag('og:title', post.meta_title || post.title);
      updateOrCreateMetaTag('og:description', post.meta_description || post.excerpt || '');
      if (post.featured_image) {
        updateOrCreateMetaTag('og:image', post.featured_image);
      }
    }

    // Cleanup - restore default title on unmount
    return () => {
      document.title = 'LDL Security';
    };
  }, [post]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-xl text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  if (!post) {
    return <NotFound />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Article Section - Unified Layout */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-24 bg-gradient-to-b from-[#0a0913] to-[#1a1435]">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Link to="/blog">
              <Button variant="ghost" className="mb-8 text-foreground/70 hover:text-foreground">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar para o Blog
              </Button>
            </Link>

            {/* Meta Information */}
            <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground mb-6">
              <span>{new Date(post.publish_date).toLocaleDateString('pt-BR')}</span>
              <span className="text-border">·</span>
              <span>{post.author}</span>
              {post.read_time && (
                <>
                  <span className="text-border">·</span>
                  <span>{post.read_time}</span>
                </>
              )}
              {post.categories && (
                <>
                  <span className="text-border">·</span>
                  <span className="text-primary">{post.categories.name}</span>
                </>
              )}
            </div>

            {/* Title */}
            <h1 className="text-3xl md:text-5xl font-bold text-foreground mb-4 leading-tight">
              {post.title}
            </h1>

            {/* Excerpt */}
            {post.excerpt && (
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                {post.excerpt}
              </p>
            )}

            {/* Featured Image */}
            {post.featured_image && (
              <img 
                src={post.featured_image}
                alt={post.title}
                className="w-full rounded-lg mb-8"
              />
            )}

            {/* Article Content */}
            <article 
              className="prose prose-invert prose-lg max-w-none
                prose-headings:text-foreground prose-headings:font-bold
                prose-h2:text-2xl prose-h2:mt-8 prose-h2:mb-4
                prose-p:text-muted-foreground prose-p:leading-relaxed prose-p:mb-4
                prose-ul:text-muted-foreground prose-ul:list-disc prose-ul:pl-6
                prose-li:mb-2
                prose-img:rounded-lg prose-img:my-6"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />

            {/* Back to Blog */}
            <div className="mt-12 pt-8 border-t border-border/30">
              <Link to="/blog">
                <Button variant="ghost" className="text-muted-foreground hover:text-foreground">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Ver todas as notícias
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default BlogArticle;
