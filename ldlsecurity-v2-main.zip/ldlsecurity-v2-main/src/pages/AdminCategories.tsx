import { Link } from "react-router-dom";
import { AdminHeader } from "@/components/admin/AdminHeader";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { CategoryManager } from "@/components/admin/CategoryManager";

const AdminCategories = () => {
  return (
    <div className="min-h-screen flex flex-col bg-section-bg">
      <AdminHeader />
      
      <main className="flex-1 pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <Link to="/admin">
              <Button variant="outline" className="mb-4">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar ao Menu
              </Button>
            </Link>
          </div>

          <CategoryManager />
        </div>
      </main>
    </div>
  );
};

export default AdminCategories;
