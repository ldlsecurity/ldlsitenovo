import { useState } from "react";
import { useForm } from "react-hook-form";
import { useCategories, Category } from "@/hooks/useCategories";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Edit } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface CategoryForm {
  name: string;
  slug: string;
}


export const CategoryManager = () => {
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<CategoryForm>();
  const { categories, loading, addCategory, updateCategory, deleteCategory } = useCategories();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  };

  const onSubmit = async (data: CategoryForm) => {
    const slug = data.slug || generateSlug(data.name);
    
    setIsSubmitting(true);
    try {
      if (editingId) {
        await updateCategory(editingId, data.name, slug);
        setEditingId(null);
      } else {
        await addCategory(data.name, slug);
      }
      reset();
    } catch (error) {
      console.error("Error submitting category:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (category: Category) => {
    setValue("name", category.name);
    setValue("slug", category.slug);
    setEditingId(category.id);
  };

  const cancelEdit = () => {
    reset();
    setEditingId(null);
  };

  return (
    <div className="space-y-8">
      {/* Form */}
      <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6">
        <h2 className="text-2xl font-bold text-white mb-6">
          {editingId ? "Editar Categoria" : "Nova Categoria"}
        </h2>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-white">Nome da Categoria</Label>
            <Input
              id="name"
              placeholder="Ex: Segurança Cibernética"
              className="bg-[#0f1729] border-gray-700 text-white"
              {...register("name", { required: "Nome é obrigatório" })}
            />
            {errors.name && (
              <p className="text-red-500 text-sm">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="slug" className="text-white">
              Slug (opcional - será gerado automaticamente)
            </Label>
            <Input
              id="slug"
              placeholder="seguranca-cibernetica"
              className="bg-[#0f1729] border-gray-700 text-white"
              {...register("slug")}
            />
          </div>

          <div className="flex gap-4">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-[#0d6efd] hover:bg-[#0b5ed7] text-white font-bold"
            >
              {isSubmitting ? (
                "Processando..."
              ) : editingId ? (
                <>
                  <Edit className="mr-2 h-4 w-4" />
                  Atualizar
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  Criar Categoria
                </>
              )}
            </Button>
            
            {editingId && (
              <Button
                type="button"
                variant="outline"
                onClick={cancelEdit}
              >
                Cancelar
              </Button>
            )}
          </div>
        </form>
      </Card>

      {/* List */}
      <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6">
        <h2 className="text-2xl font-bold text-white mb-6">
          Categorias Cadastradas
        </h2>

        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-white">Nome</TableHead>
              <TableHead className="text-white">Slug</TableHead>
              <TableHead className="text-white">Data</TableHead>
              <TableHead className="text-white">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center text-gray-400">
                  Carregando...
                </TableCell>
              </TableRow>
            ) : categories.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center text-gray-400">
                  Nenhuma categoria cadastrada
                </TableCell>
              </TableRow>
            ) : (
              categories.map((category) => (
                <TableRow key={category.id} className="border-gray-700">
                  <TableCell className="text-gray-300 font-medium">
                    {category.name}
                  </TableCell>
                  <TableCell className="text-[#60a5fa] font-mono">
                    {category.slug}
                  </TableCell>
                  <TableCell className="text-gray-300">
                    {new Date(category.created_at).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(category)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => deleteCategory(category.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};
