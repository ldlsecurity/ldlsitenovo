import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { FileText, Trash2, ExternalLink, Edit, Plus, X } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useCertificates } from "@/hooks/useCertificates";

interface CertificateForm {
  cnpj: string;
  companyName: string;
  domains: { value: string }[];
  document: FileList;
}

export const CertificateManager = () => {
  const { register, handleSubmit, reset, setValue, control, formState: { errors } } = useForm<CertificateForm>({
    defaultValues: {
      domains: [{ value: "" }]
    }
  });
  const { fields, append, remove } = useFieldArray({
    control,
    name: "domains"
  });
  const { certificates, loading, addCertificate, updateCertificate, deleteCertificate } = useCertificates();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const onSubmit = async (data: CertificateForm) => {
    if (!data.document || data.document.length === 0) {
      return;
    }

    const domains = data.domains.map(d => d.value).filter(v => v.trim() !== "");

    setIsSubmitting(true);
    try {
      if (editingId) {
        await updateCertificate(editingId, data.cnpj, data.companyName, domains, data.document[0]);
        setEditingId(null);
      } else {
        await addCertificate(data.cnpj, data.companyName, domains, data.document[0]);
      }
      reset({ domains: [{ value: "" }] });
    } catch (error) {
      console.error("Error submitting certificate:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (certificate: any) => {
    setValue("cnpj", certificate.cnpj);
    setValue("companyName", certificate.company_name);
    setValue("domains", certificate.domains?.length > 0 
      ? certificate.domains.map((d: string) => ({ value: d }))
      : [{ value: "" }]
    );
    setEditingId(certificate.id);
  };

  const cancelEdit = () => {
    reset({ domains: [{ value: "" }] });
    setEditingId(null);
  };

  return (
    <div className="space-y-8">
      {/* Form */}
      <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6">
        <h2 className="text-2xl font-bold text-white mb-6">
          {editingId ? "Editar Certificado" : "Novo Certificado"}
        </h2>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="cnpj" className="text-white">CNPJ</Label>
            <Input
              id="cnpj"
              placeholder="00.000.000/0000-00"
              className="bg-[#0f1729] border-gray-700 text-white"
              {...register("cnpj", { required: "CNPJ é obrigatório" })}
            />
            {errors.cnpj && (
              <p className="text-red-500 text-sm">{errors.cnpj.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="companyName" className="text-white">Nome da Empresa</Label>
            <Input
              id="companyName"
              placeholder="Nome da empresa"
              className="bg-[#0f1729] border-gray-700 text-white"
              {...register("companyName", { required: "Nome é obrigatório" })}
            />
            {errors.companyName && (
              <p className="text-red-500 text-sm">{errors.companyName.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label className="text-white">Domínios</Label>
            <div className="space-y-2">
              {fields.map((field, index) => (
                <div key={field.id} className="flex gap-2">
                  <Input
                    placeholder="exemplo.com.br"
                    className="bg-[#0f1729] border-gray-700 text-white flex-1"
                    {...register(`domains.${index}.value` as const)}
                  />
                  {fields.length > 1 && (
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      onClick={() => remove(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => append({ value: "" })}
              className="mt-2"
            >
              <Plus className="mr-2 h-4 w-4" />
              Adicionar Domínio
            </Button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="document" className="text-white">
              Documento (PDF) {editingId && "(opcional para atualização)"}
            </Label>
            <Input
              id="document"
              type="file"
              accept=".pdf"
              className="bg-[#0f1729] border-gray-700 text-white"
              {...register("document", { required: !editingId })}
            />
            {errors.document && (
              <p className="text-red-500 text-sm">Documento é obrigatório</p>
            )}
          </div>

          <div className="flex gap-4">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-[#0d6efd] hover:bg-[#0b5ed7] text-white font-bold flex-1"
            >
              {isSubmitting ? (
                "Processando..."
              ) : editingId ? (
                <>
                  <Edit className="mr-2 h-4 w-4" />
                  Atualizar
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  Criar Certificado
                </>
              )}
            </Button>
            
            {editingId && (
              <Button
                type="button"
                variant="outline"
                onClick={cancelEdit}
              >
                Cancelar
              </Button>
            )}
          </div>
        </form>
      </Card>

      {/* List */}
      <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6">
        <h2 className="text-2xl font-bold text-white mb-6">
          Certificados Cadastrados
        </h2>

        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-white">CNPJ</TableHead>
              <TableHead className="text-white">Empresa</TableHead>
              <TableHead className="text-white">Chave</TableHead>
              <TableHead className="text-white">Data</TableHead>
              <TableHead className="text-white">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-gray-400">
                  Carregando...
                </TableCell>
              </TableRow>
            ) : certificates.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-gray-400">
                  Nenhum certificado cadastrado
                </TableCell>
              </TableRow>
            ) : (
              certificates.map((certificate) => (
                <TableRow key={certificate.id} className="border-gray-700">
                  <TableCell className="text-gray-300 font-medium">
                    {certificate.cnpj}
                  </TableCell>
                  <TableCell className="text-gray-300">
                    {certificate.company_name}
                  </TableCell>
                  <TableCell className="text-[#60a5fa] font-mono">
                    {certificate.validation_key}
                  </TableCell>
                  <TableCell className="text-gray-300">
                    {new Date(certificate.created_at).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(certificate)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        asChild
                      >
                        <a href={certificate.document_url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => deleteCertificate(certificate.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};
