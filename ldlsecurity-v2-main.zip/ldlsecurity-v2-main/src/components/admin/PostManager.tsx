import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit, Eye } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { usePosts } from "@/hooks/usePosts";
import { useCategories } from "@/hooks/useCategories";

export const PostManager = () => {
  const { posts, loading, deletePost } = usePosts();
  const { categories } = useCategories();

  const getCategoryName = (categoryId: string | null) => {
    if (!categoryId) return "Sem categoria";
    const category = categories.find(c => c.id === categoryId);
    return category?.name || "Desconhecida";
  };

  return (
    <div className="space-y-8">
      {/* Header with New Post Button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">Posts do Blog</h2>
          <p className="text-gray-400 mt-1">
            Gerencie todos os posts publicados
          </p>
        </div>
        <Link to="/admin/posts/novo">
          <Button className="bg-[#0d6efd] hover:bg-[#0b5ed7] text-white font-bold">
            <Plus className="mr-2 h-4 w-4" />
            Novo Post
          </Button>
        </Link>
      </div>

      {/* Posts List */}
      <Card className="bg-[#1a1f2e]/50 border-gray-700/30 p-6">
        {loading ? (
          <div className="text-center py-16 text-gray-400">
            Carregando posts...
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-gray-400 mb-4">
              Nenhum post cadastrado ainda
            </p>
            <Link to="/admin/posts/novo">
              <Button className="bg-[#0d6efd] hover:bg-[#0b5ed7]">
                <Plus className="mr-2 h-4 w-4" />
                Criar Primeiro Post
              </Button>
            </Link>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700">
                <TableHead className="text-white">Título</TableHead>
                <TableHead className="text-white">Categoria</TableHead>
                <TableHead className="text-white">Autor</TableHead>
                <TableHead className="text-white">Data</TableHead>
                <TableHead className="text-white">Status</TableHead>
                <TableHead className="text-white">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {posts.map((post) => (
                <TableRow key={post.id} className="border-gray-700">
                  <TableCell className="text-gray-300 font-medium">
                    {post.title}
                  </TableCell>
                  <TableCell className="text-gray-300">
                    {getCategoryName(post.category_id)}
                  </TableCell>
                  <TableCell className="text-gray-300">
                    {post.author}
                  </TableCell>
                  <TableCell className="text-gray-300">
                    {new Date(post.publish_date).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      post.published 
                        ? 'bg-green-500/20 text-green-400' 
                        : 'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {post.published ? 'Publicado' : 'Rascunho'}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Link to={`/blog/${post.slug}`} target="_blank">
                        <Button
                          size="sm"
                          variant="outline"
                        >
                          Ver
                        </Button>
                      </Link>
                      <Link to={`/admin/posts/editar/${post.slug}`}>
                        <Button
                          size="sm"
                          variant="outline"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </Link>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => deletePost(post.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
};
