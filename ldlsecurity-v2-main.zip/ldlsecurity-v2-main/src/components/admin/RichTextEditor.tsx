import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';
import Image from '@tiptap/extension-image';
import TextAlign from '@tiptap/extension-text-align';
import { Extension } from '@tiptap/core';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Bold,
  Italic,
  Underline as UnderlineIcon,
  List,
  ListOrdered,
  Heading1,
  Heading2,
  Heading3,
  Image as ImageIcon,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Code,
} from 'lucide-react';
import { useState } from 'react';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { useUploadFile } from '@/hooks/useUploadFile';
import { useToast } from '@/hooks/use-toast';

// Custom extension for font size
const FontSize = Extension.create({
  name: 'fontSize',
  
  addOptions() {
    return {
      types: ['textStyle'],
    };
  },
  
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          fontSize: {
            default: null,
            parseHTML: element => element.style.fontSize || null,
            renderHTML: attributes => {
              if (!attributes.fontSize) {
                return {};
              }
              return {
                style: `font-size: ${attributes.fontSize}`,
              };
            },
          },
        },
      },
    ];
  },
});

interface RichTextEditorProps {
  content: string;
  onChange: (content: string) => void;
}

const RichTextEditor = ({ content, onChange }: RichTextEditorProps) => {
  const [showImageDialog, setShowImageDialog] = useState(false);
  const [imageUrl, setImageUrl] = useState('');
  const [imageAlt, setImageAlt] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [uploadMode, setUploadMode] = useState<'url' | 'upload'>('url');
  const [showHtmlMode, setShowHtmlMode] = useState(false);
  const [htmlContent, setHtmlContent] = useState(content);
  const { uploadFile, uploading } = useUploadFile();
  const { toast } = useToast();

  const editor = useEditor({
    immediatelyRender: false,
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [1, 2, 3],
        },
        // Remove strike from StarterKit to avoid conflicts
        strike: false,
      }),
      Underline,
      TextStyle,
      FontSize,
      Color,
      Image.configure({
        HTMLAttributes: {
          class: 'max-w-full h-auto rounded-lg my-4',
        },
      }),
      TextAlign.configure({
        types: ['heading', 'paragraph'],
      }),
    ],
    content,
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      onChange(html);
      setHtmlContent(html);
    },
    editorProps: {
      attributes: {
        class: 'prose prose-invert max-w-none min-h-[400px] px-4 py-3 focus:outline-none',
      },
    },
  });

  if (!editor) {
    return null;
  }

  const addImage = async () => {
    if (uploadMode === 'url' && imageUrl) {
      editor.chain().focus().setImage({ src: imageUrl, alt: imageAlt }).run();
      setImageUrl('');
      setImageAlt('');
      setImageFile(null);
      setShowImageDialog(false);
    } else if (uploadMode === 'upload' && imageFile) {
      // Upload file to Supabase storage
      const url = await uploadFile('blog-images', imageFile);
      if (url) {
        editor.chain().focus().setImage({ src: url, alt: imageAlt }).run();
        toast({ title: "Imagem enviada com sucesso!" });
      }
      setImageUrl('');
      setImageAlt('');
      setImageFile(null);
      setShowImageDialog(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
    }
  };

  const toggleHtmlMode = () => {
    if (showHtmlMode) {
      // Switching from HTML to visual mode
      editor?.commands.setContent(htmlContent);
      onChange(htmlContent);
    } else {
      // Switching from visual to HTML mode
      setHtmlContent(editor?.getHTML() || '');
    }
    setShowHtmlMode(!showHtmlMode);
  };

  const handleHtmlChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newHtml = e.target.value;
    setHtmlContent(newHtml);
    onChange(newHtml);
  };

  const ToolbarButton = ({ onClick, active, children, title }: any) => (
    <Button
      type="button"
      size="sm"
      variant={active ? 'secondary' : 'ghost'}
      onClick={onClick}
      className="h-8 w-8 p-0"
      title={title}
    >
      {children}
    </Button>
  );

  return (
    <div className="border border-gray-700 rounded-lg bg-[#0f1729]">
      {/* Toolbar */}
      <div className="border-b border-gray-700 p-2 flex flex-wrap gap-1">
        {/* Text Formatting */}
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleBold().run()}
          active={editor.isActive('bold')}
          title="Negrito"
        >
          <Bold className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleItalic().run()}
          active={editor.isActive('italic')}
          title="Itálico"
        >
          <Italic className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleUnderline().run()}
          active={editor.isActive('underline')}
          title="Sublinhado"
        >
          <UnderlineIcon className="h-4 w-4" />
        </ToolbarButton>

        <div className="w-px h-8 bg-gray-700 mx-1" />

        {/* Headings */}
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
          active={editor.isActive('heading', { level: 1 })}
          title="Título 1"
        >
          <Heading1 className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          active={editor.isActive('heading', { level: 2 })}
          title="Título 2"
        >
          <Heading2 className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
          active={editor.isActive('heading', { level: 3 })}
          title="Título 3"
        >
          <Heading3 className="h-4 w-4" />
        </ToolbarButton>

        <div className="w-px h-8 bg-gray-700 mx-1" />

        {/* Lists */}
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          active={editor.isActive('bulletList')}
          title="Lista com marcadores"
        >
          <List className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          active={editor.isActive('orderedList')}
          title="Lista numerada"
        >
          <ListOrdered className="h-4 w-4" />
        </ToolbarButton>

        <div className="w-px h-8 bg-gray-700 mx-1" />

        {/* Alignment */}
        <ToolbarButton
          onClick={() => editor.chain().focus().setTextAlign('left').run()}
          active={editor.isActive({ textAlign: 'left' })}
          title="Alinhar à esquerda"
        >
          <AlignLeft className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().setTextAlign('center').run()}
          active={editor.isActive({ textAlign: 'center' })}
          title="Centralizar"
        >
          <AlignCenter className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().setTextAlign('right').run()}
          active={editor.isActive({ textAlign: 'right' })}
          title="Alinhar à direita"
        >
          <AlignRight className="h-4 w-4" />
        </ToolbarButton>

        <div className="w-px h-8 bg-gray-700 mx-1" />

        {/* Color Picker */}
        <input
          type="color"
          onInput={(e) => editor.chain().focus().setColor((e.target as HTMLInputElement).value).run()}
          value={editor.getAttributes('textStyle').color || '#ffffff'}
          className="h-8 w-8 rounded border border-gray-700 bg-transparent cursor-pointer"
          title="Cor do texto"
        />

        <div className="w-px h-8 bg-gray-700 mx-1" />

        {/* Font Size */}
        <select
          onChange={(e) => {
            const size = e.target.value;
            if (size) {
              editor.chain().focus().setMark('textStyle', { fontSize: size }).run();
            } else {
              editor.chain().focus().setMark('textStyle', { fontSize: null }).run();
            }
          }}
          className="h-8 px-2 rounded bg-[#1a1f2e] border border-gray-700 text-white text-sm"
          title="Tamanho da fonte"
        >
          <option value="">Tamanho</option>
          <option value="12px">12px</option>
          <option value="14px">14px</option>
          <option value="16px">16px</option>
          <option value="18px">18px</option>
          <option value="20px">20px</option>
          <option value="24px">24px</option>
          <option value="32px">32px</option>
        </select>

        <div className="w-px h-8 bg-gray-700 mx-1" />

        {/* Image */}
        <ToolbarButton
          onClick={() => setShowImageDialog(true)}
          active={false}
          title="Inserir imagem"
        >
          <ImageIcon className="h-4 w-4" />
        </ToolbarButton>

        <div className="w-px h-8 bg-gray-700 mx-1" />

        {/* HTML Mode Toggle */}
        <ToolbarButton
          onClick={toggleHtmlMode}
          active={showHtmlMode}
          title={showHtmlMode ? "Modo visual" : "Ver código HTML"}
        >
          <Code className="h-4 w-4" />
        </ToolbarButton>
      </div>

      {/* Editor Content */}
      {showHtmlMode ? (
        <Textarea
          value={htmlContent}
          onChange={handleHtmlChange}
          className="min-h-[400px] font-mono text-sm bg-[#0f1729] border-0 text-white resize-none"
          placeholder="Cole ou edite o código HTML aqui..."
        />
      ) : (
        <EditorContent editor={editor} className="text-white" />
      )}

      {/* Image Dialog */}
      <Dialog open={showImageDialog} onOpenChange={setShowImageDialog}>
        <DialogContent className="bg-[#1a1f2e] border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Inserir Imagem</DialogTitle>
            <DialogDescription className="text-gray-400">
              Adicione uma imagem ao conteúdo através de URL ou upload de arquivo
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Toggle between URL and Upload */}
            <div className="flex gap-2">
              <Button
                type="button"
                size="sm"
                variant={uploadMode === 'url' ? 'secondary' : 'outline'}
                onClick={() => setUploadMode('url')}
                className="flex-1"
              >
                URL da Imagem
              </Button>
              <Button
                type="button"
                size="sm"
                variant={uploadMode === 'upload' ? 'secondary' : 'outline'}
                onClick={() => setUploadMode('upload')}
                className="flex-1"
              >
                Fazer Upload
              </Button>
            </div>

            {uploadMode === 'url' ? (
              <div className="space-y-2">
                <Label htmlFor="imageUrl" className="text-white">
                  URL da Imagem
                </Label>
                <Input
                  id="imageUrl"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://exemplo.com/imagem.jpg"
                  className="bg-[#0f1729] border-gray-700 text-white"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="imageFile" className="text-white">
                  Selecionar Arquivo
                </Label>
                <Input
                  id="imageFile"
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="bg-[#0f1729] border-gray-700 text-white"
                />
                {imageFile && (
                  <p className="text-sm text-gray-400">
                    Arquivo selecionado: {imageFile.name}
                  </p>
                )}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="imageAlt" className="text-white">
                Texto Alternativo (Alt)
              </Label>
              <Input
                id="imageAlt"
                value={imageAlt}
                onChange={(e) => setImageAlt(e.target.value)}
                placeholder="Descrição da imagem"
                className="bg-[#0f1729] border-gray-700 text-white"
              />
              <p className="text-xs text-gray-400">
                Importante para SEO e acessibilidade
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowImageDialog(false);
                setImageUrl('');
                setImageAlt('');
                setImageFile(null);
              }}
              disabled={uploading}
            >
              Cancelar
            </Button>
            <Button
              type="button"
              onClick={addImage}
              disabled={(uploadMode === 'url' ? !imageUrl : !imageFile) || uploading}
              className="bg-[#0d6efd] hover:bg-[#0b5ed7]"
            >
              {uploading ? "Enviando..." : "Inserir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RichTextEditor;
