import { Badge } from "@/components/ui/badge";
import logoImage from "@/assets/ldl-logo-full.png";
import { useCountUp } from "@/hooks/useCountUp";

const Stats = () => {
  const { count: count100, ref: ref100 } = useCountUp({ end: 100, increment: 10 });
  const { count: count1000, ref: ref1000 } = useCountUp({ end: 1000, increment: 100 });
  const { count: count5, ref: ref5 } = useCountUp({ end: 5, increment: 1 });

  return (
    <section id="sobre" className="py-16 md:py-24 bg-[hsl(var(--bg-navy))]">
      <div className="container mx-auto px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-foreground mb-16">
          Números que<br />
          Comprovam Nossa Excelência
        </h2>

        <div className="grid lg:grid-cols-2 gap-8 items-start">
          <div className="bg-card p-8 rounded-lg border border-border relative">
            <Badge className="absolute top-4 left-4 bg-primary/20 text-primary">
              Sobre
            </Badge>
            <h3 className="text-2xl md:text-3xl font-medium text-foreground mt-12 mb-6">
              Nossa equipe de especialistas altamente qualificados utiliza
              metodologias avançadas para identificar vulnerabilidades e
              fortalecer a postura de segurança de nossos clientes, protegendo
              seus ativos digitais contra ameaças emergentes.
            </h3>
            
            <div className="mb-8">
              <h4 className="text-lg font-bold text-foreground mb-4">
                Anos de experiência neutralizando ameaças reais
              </h4>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span><strong className="text-foreground">Identificação de Vulnerabilidades:</strong> Identificamos falhas críticas em aplicações web, mobile e infraestrutura antes que hackers possam explorá-las.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span><strong className="text-foreground">Postura de Segurança Fortalecida:</strong> Fortaleça suas defesas cibernéticas com recomendações práticas baseadas em testes reais de penetração.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span><strong className="text-foreground">Conformidade Regulatória:</strong> Garanta conformidade com LGPD, GDPR e PCI-DSS, evitando multas e protegendo sua reputação.</span>
                </li>
              </ul>
            </div>
            
            <div className="flex items-center gap-4 mt-8">
              <img alt="LDL logo" className="h-12" src={logoImage} />
              <div>
                <p className="font-bold text-foreground">LDL CyberSecurity</p>
                <p className="text-sm text-muted-foreground">
                  Protegendo empresas brasileiras contra ameaças cibernéticas
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-card p-6 md:p-8 rounded-lg border border-border" ref={ref100}>
              <div className="flex flex-col gap-3 mb-4">
                <Badge className="bg-primary/20 text-primary w-fit">
                  Clientes protegidos
                </Badge>
                <p className="text-5xl md:text-6xl font-bold text-primary">{count100}+</p>
              </div>
              <p className="text-muted-foreground">
                Identificamos falhas críticas em aplicações web, mobile e
                infraestrutura antes que hackers possam explorá-las.
              </p>
            </div>

            <div className="bg-card p-6 md:p-8 rounded-lg border border-border" ref={ref1000}>
              <div className="flex flex-col gap-3 mb-4">
                <Badge className="bg-primary/20 text-primary w-fit">
                  Vulnerabilidades
                </Badge>
                <p className="text-5xl md:text-6xl font-bold text-primary">{count1000.toLocaleString('pt-BR')}+</p>
              </div>
              <p className="text-muted-foreground">
                Falhas de segurança identificadas e corrigidas nos sistemas de
                nossos clientes ao longo dos anos.
              </p>
            </div>

            <div className="bg-card p-6 md:p-8 rounded-lg border border-border" ref={ref5}>
              <div className="flex flex-col gap-3 mb-4">
                <Badge className="bg-primary/20 text-primary w-fit">
                  Experiência
                </Badge>
                <p className="text-5xl md:text-6xl font-bold text-primary">{count5} anos</p>
              </div>
              <p className="text-muted-foreground">
                Fortaleça suas defesas cibernéticas com recomendações práticas
                baseadas em testes reais de penetração.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Stats;
