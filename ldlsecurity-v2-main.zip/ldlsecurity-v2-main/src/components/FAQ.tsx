import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ = () => {
  return (
    <section id="faq" className="py-16 md:py-24 bg-[hsl(var(--bg-navy))]">
      <div className="container mx-auto px-6 lg:px-8 max-w-3xl">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Dúvidas Frequentes
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore as perguntas a seguir para entender melhor como a LDL Security pode proteger sua empresa contra ameaças cibernéticas.
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          <AccordionItem
            value="item-1"
            className="bg-card border border-border rounded-lg px-6"
          >
            <AccordionTrigger className="text-left font-bold text-lg text-foreground hover:no-underline">
              O que é um Pentest?
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              O pentest (teste de penetração) é uma simulação autorizada de um ataque cibernético, realizada para identificar vulnerabilidades nos sistemas, redes e aplicações de uma organização antes que atacantes reais possam explorá-las. O objetivo é encontrar e corrigir falhas de segurança proativamente.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem
            value="item-2"
            className="bg-card border border-border rounded-lg px-6"
          >
            <AccordionTrigger className="text-left font-bold text-lg text-foreground hover:no-underline">
              Por que minha empresa brasileira precisa de pentest?
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Com o aumento constante de ataques cibernéticos no Brasil e a entrada em vigor da LGPD, realizar pentests periódicos é essencial para proteger dados sensíveis, evitar perdas financeiras (média de R$5,8 milhões por violação no Brasil) e manter conformidade com as regulamentações. Detectamos falhas de segurança que poderiam ser exploradas por criminosos cibernéticos.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem
            value="item-3"
            className="bg-card border border-border rounded-lg px-6"
          >
            <AccordionTrigger className="text-left font-bold text-lg text-foreground hover:no-underline">
              Quais tipos de pentest a LDL Security realiza?
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Oferecemos pentests especializados em: aplicações web (OWASP Top 10), aplicativos mobile (iOS/Android), infraestrutura e redes, análise de código-fonte, engenharia social e simulação de ataques avançados (Red Team). Cada modalidade é personalizada conforme as necessidades específicas da sua empresa.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem
            value="item-4"
            className="bg-card border border-border rounded-lg px-6"
          >
            <AccordionTrigger className="text-left font-bold text-lg text-foreground hover:no-underline">
              O pentest pode interromper os serviços da minha empresa?
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Não. Nossos testes são cuidadosamente planejados e executados para minimizar qualquer impacto nos sistemas em produção. Trabalhamos em horários de baixo tráfego e utilizamos técnicas não-invasivas sempre que possível. Para testes mais intensivos, podemos utilizar ambientes de homologação ou criar janelas de manutenção programadas.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </section>
  );
};

export default FAQ;
