import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import abrapa from "@/assets/clients/abrapa.webp";
import cloudx from "@/assets/clients/cloudx.webp";
import ultrasis from "@/assets/clients/ultrasis.webp";
import rubeus from "@/assets/clients/rubeus.webp";
import sedep from "@/assets/clients/sedep.webp";
import helpEngenharia from "@/assets/clients/help-engenharia.webp";
import meuPreparatorio from "@/assets/clients/meu-preparatorio.webp";
import tksgo from "@/assets/clients/tksgo.webp";
import openmanager from "@/assets/clients/openmanager.webp";
import demander from "@/assets/clients/demander.webp";

const TrustedBy = () => {
  const clients = [
    { name: "Abrapa", logo: abrapa },
    { name: "CloudX", logo: cloudx },
    { name: "Ultrasis", logo: ultrasis },
    { name: "Rubeus", logo: rubeus },
    { name: "Sedep", logo: sedep },
    { name: "Help Engenharia", logo: helpEngenharia },
    { name: "Meu Preparatório", logo: meuPreparatorio },
    { name: "TKS Go", logo: tksgo },
    { name: "OpenManager", logo: openmanager },
    { name: "Demander", logo: demander },
  ];

  return (
    <section id="clientes" className="py-16 md:py-24 bg-gradient-to-r from-[hsl(var(--bg-dark-blue))] to-[hsl(var(--bg-purple-blue))]">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Empresas que Confiam em Nossa Expertise
          </h2>
          <p className="text-muted-foreground">
            Clientes que protegemos contra ameaças cibernéticas
          </p>
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          plugins={[
            Autoplay({
              delay: 2000,
            }),
          ]}
          className="w-full"
        >
          <CarouselContent>
            {clients.map((client, index) => (
              <CarouselItem key={index} className="md:basis-1/3 lg:basis-1/5">
                <div className="bg-card border border-border rounded-lg p-8 flex items-center justify-center h-32 hover:border-primary/50 transition-colors">
                  <img
                    src={client.logo}
                    alt={`${client.name} logo`}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
        </Carousel>
      </div>
    </section>
  );
};

export default TrustedBy;
