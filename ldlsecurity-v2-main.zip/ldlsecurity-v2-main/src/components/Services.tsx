import { Shield, Lock, Eye, Globe, AlertTriangle, GraduationCap, ShieldCheck, Smartphone } from "lucide-react";
import securityServer from "@/assets/security-server.jpg";

const Services = () => {
  return (
    <section id="servicos" className="py-16 md:py-24 bg-[hsl(var(--bg-navy))]">
      <div className="container mx-auto px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
          Soluções de<br />
          Cibersegurança
        </h2>
        <p className="max-w-lg mx-auto text-muted-foreground mb-16">
          Metodologias avançadas para identificar vulnerabilidades antes que
          invasores possam explorá-las
        </p>

        <div className="bg-card border border-border rounded-lg p-0 mb-16 overflow-hidden relative">
          <div 
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: `url(${securityServer})`,
              backgroundSize: 'cover',
              backgroundPosition: 'right center',
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/95 to-background/30"></div>
          </div>
          
          <div className="relative z-10 p-8 flex items-center gap-6">
            <div className="hidden md:flex items-center justify-center">
              <div className="bg-accent/10 p-6 rounded-full border-2 border-accent">
                <ShieldCheck className="w-16 h-16 text-accent" />
              </div>
            </div>
            
            <div className="text-left flex-1">
              <h3 className="text-3xl font-bold text-foreground mb-4">
                Segurança Completa para sua Empresa
              </h3>
              <p className="text-muted-foreground max-w-3xl">
                Nossos serviços de Pentest abrangem aplicações web, mobile e
                infraestrutura, garantindo uma cobertura completa. Utilizamos
                abordagens BlackBox, WhiteBox e GreyBox para simular ataques
                realistas e identificar vulnerabilidades em todas as camadas do
                seu ambiente digital.
              </p>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 text-left">
          <div className="group bg-card p-8 rounded-lg border-2 border-border text-center flex flex-col items-center hover:border-accent transition-all duration-300 hover:shadow-[0_0_30px_rgba(174,243,52,0.3)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent animate-pulse"></div>
            <div className="bg-accent/10 p-5 rounded-full border-2 border-accent mb-6 group-hover:scale-110 transition-transform duration-300">
              <Shield className="w-16 h-16 text-accent" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Pentest BlackBox
            </h3>
            <p className="text-muted-foreground flex-grow">
              Simulamos ataques reais sem conhecimento prévio da infraestrutura,
              testando suas defesas externas como um invasor faria.
            </p>
          </div>

          <div className="group bg-card p-8 rounded-lg border-2 border-border text-center flex flex-col items-center hover:border-accent transition-all duration-300 hover:shadow-[0_0_30px_rgba(174,243,52,0.3)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent animate-pulse"></div>
            <div className="bg-accent/10 p-5 rounded-full border-2 border-accent mb-6 group-hover:scale-110 transition-transform duration-300">
              <Lock className="w-16 h-16 text-accent" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Pentest WhiteBox
            </h3>
            <p className="text-muted-foreground flex-grow">
              Análise profunda com acesso ao código-fonte e documentação,
              identificando vulnerabilidades em nível de implementação.
            </p>
          </div>

          <div className="group bg-card p-8 rounded-lg border-2 border-border text-center flex flex-col items-center hover:border-accent transition-all duration-300 hover:shadow-[0_0_30px_rgba(174,243,52,0.3)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent animate-pulse"></div>
            <div className="bg-accent/10 p-5 rounded-full border-2 border-accent mb-6 group-hover:scale-110 transition-transform duration-300">
              <Eye className="w-16 h-16 text-accent" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Threat Intelligence
            </h3>
            <p className="text-muted-foreground flex-grow">
              Monitoramento de ameaças e vazamentos na dark web relacionados à
              sua empresa e colaboradores.
            </p>
          </div>

          <div className="group bg-card p-8 rounded-lg border-2 border-border text-center flex flex-col items-center hover:border-accent transition-all duration-300 hover:shadow-[0_0_30px_rgba(174,243,52,0.3)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent animate-pulse"></div>
            <div className="bg-accent/10 p-5 rounded-full border-2 border-accent mb-6 group-hover:scale-110 transition-transform duration-300">
              <Globe className="w-16 h-16 text-accent" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Pentest Web
            </h3>
            <p className="text-muted-foreground flex-grow">
              Análise especializada de aplicações web para identificar vulnerabilidades como SQLi, XSS, CSRF e falhas de autenticação.
            </p>
          </div>

          <div className="group bg-card p-8 rounded-lg border-2 border-border text-center flex flex-col items-center hover:border-accent transition-all duration-300 hover:shadow-[0_0_30px_rgba(174,243,52,0.3)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent animate-pulse"></div>
            <div className="bg-accent/10 p-5 rounded-full border-2 border-accent mb-6 group-hover:scale-110 transition-transform duration-300">
              <AlertTriangle className="w-16 h-16 text-accent" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Resposta a Incidentes
            </h3>
            <p className="text-muted-foreground flex-grow">
              Equipe especializada para detecção, análise e resposta a incidentes de segurança com máxima agilidade.
            </p>
          </div>

          <div className="group bg-card p-8 rounded-lg border-2 border-border text-center flex flex-col items-center hover:border-accent transition-all duration-300 hover:shadow-[0_0_30px_rgba(174,243,52,0.3)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent animate-pulse"></div>
            <div className="bg-accent/10 p-5 rounded-full border-2 border-accent mb-6 group-hover:scale-110 transition-transform duration-300">
              <GraduationCap className="w-16 h-16 text-accent" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Treinamento Técnico
            </h3>
            <p className="text-muted-foreground flex-grow">
              Capacitação técnica para equipes de desenvolvimento e operações com foco em desenvolvimento seguro (DevSecOps).
            </p>
          </div>

          <div className="group bg-card p-8 rounded-lg border-2 border-border text-center flex flex-col items-center hover:border-accent transition-all duration-300 hover:shadow-[0_0_30px_rgba(174,243,52,0.3)] relative overflow-hidden md:col-span-3">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent animate-pulse"></div>
            <div className="bg-accent/10 p-5 rounded-full border-2 border-accent mb-6 group-hover:scale-110 transition-transform duration-300">
              <Smartphone className="w-16 h-16 text-accent" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Pentest Mobile
            </h3>
            <p className="text-muted-foreground flex-grow max-w-3xl">
              Análise completa de segurança para aplicativos iOS e Android, incluindo testes de comunicação, armazenamento local, autenticação, criptografia e vulnerabilidades específicas de plataformas móveis.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
