import { Button } from "@/components/ui/button";
// import ShaderBackground from "@/components/ui/shader-background";
import { Shield } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import logoImage from "@/assets/ldl-logo-full.png";
import abrapa from "@/assets/clients/abrapa.webp";
import cloudx from "@/assets/clients/cloudx.webp";
import ultrasis from "@/assets/clients/ultrasis.webp";
import rubeus from "@/assets/clients/rubeus.webp";
import sedep from "@/assets/clients/sedep.webp";
import helpEngenharia from "@/assets/clients/help-engenharia.webp";
import meuPreparatorio from "@/assets/clients/meu-preparatorio.webp";
import tksgo from "@/assets/clients/tksgo.webp";
import openmanager from "@/assets/clients/openmanager.webp";
import demander from "@/assets/clients/demander.webp";
const Hero = () => {
  const clients = [{
    name: "Abrapa",
    logo: abrapa
  }, {
    name: "CloudX",
    logo: cloudx
  }, {
    name: "Ultrasis",
    logo: ultrasis
  }, {
    name: "Rubeus",
    logo: rubeus
  }, {
    name: "Sedep",
    logo: sedep
  }, {
    name: "Help Engenharia",
    logo: helpEngenharia
  }, {
    name: "Meu Preparatório",
    logo: meuPreparatorio
  }, {
    name: "TKS Go",
    logo: tksgo
  }, {
    name: "OpenManager",
    logo: openmanager
  }, {
    name: "Demander",
    logo: demander
  }];
  return <section id="inicio" className="relative min-h-screen flex items-center justify-center text-center text-foreground bg-gradient-to-r from-[hsl(var(--bg-dark-blue))] to-[hsl(var(--bg-purple-blue))] overflow-hidden">
      {/* <ShaderBackground /> */}
      <iframe
        className="absolute inset-0 w-full h-full object-cover pointer-events-none"
        src="https://www.youtube.com/embed/QgaQRVdXzE0?autoplay=1&mute=1&loop=1&playlist=QgaQRVdXzE0&controls=0&showinfo=0&rel=0&modestbranding=1"
        title="Hero Background Video"
        allow="autoplay; encrypted-media"
        style={{ transform: 'scale(1.5)', opacity: 0.3 }}
      ></iframe>
      <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent/50 to-transparent"></div>

      <div className="relative z-10 container mx-auto px-6 lg:px-8 pt-28 md:pt-32">
        <div className="flex justify-center mb-8">
          <img alt="LDL Security Logo" className="h-12 md:h-16" src="/lovable-uploads/588ce62d-0479-4dae-8eb5-9296735b99f9.webp" />
        </div>
        
        <div className="inline-flex items-center gap-2 bg-card/50 border border-border rounded-full px-4 py-1.5 text-sm mb-6 backdrop-blur-sm">
          <span className="w-2 h-2 rounded-full bg-primary"></span>
          Segurança Cibernética Especializada
        </div>

        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6">
          Protegendo empresas<br />
          brasileiras contra<br />
          ameaças cibernéticas
        </h1>

        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          LDL Security é especializada em pentest web, mobile e infraestrutura. 
          Identificamos vulnerabilidades antes que hackers possam explorá-las.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <Button size="lg" className="w-full sm:w-auto" asChild>
            <a href="https://wa.me/5551993704573?text=Olá!%20Gostaria%20de%20solicitar%20um%20orçamento." target="_blank" rel="noopener noreferrer">
              <Shield className="w-5 h-5" />
              Solicite um orçamento
            </a>
          </Button>
        </div>

        <div className="mt-20 py-0 my-[50px]">
          <p className="text-xs font-light text-white/50 mb-8">Empresas que confiam em nossa expertise</p>
          <Carousel opts={{
          align: "start",
          loop: true
        }} plugins={[Autoplay({
          delay: 2000
        })]} className="w-full max-w-5xl mx-auto">
            <CarouselContent>
              {clients.map((client, index) => <CarouselItem key={index} className="basis-1/3 md:basis-1/5 lg:basis-1/6">
                  <div className="flex items-center justify-center h-8 grayscale opacity-40 hover:opacity-60 transition-opacity">
                    <img src={client.logo} alt={`${client.name} logo`} className="h-full w-auto object-contain brightness-0 invert" />
                  </div>
                </CarouselItem>)}
            </CarouselContent>
          </Carousel>
        </div>
      </div>
    </section>;
};
export default Hero;