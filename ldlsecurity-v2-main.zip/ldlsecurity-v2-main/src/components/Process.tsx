const Process = () => {
  const steps = [
    {
      number: "1",
      title: "Análise de Escopo",
      description:
        "Reunião para entender os objetivos, ativos críticos e limites do teste de penetração.",
    },
    {
      number: "2",
      title: "Execução do Pentest",
      description:
        "Utilizamos técnicas próprias e tecnologias avançadas para identificar vulnerabilidades em todas as camadas da aplicação ou da infraestrutura.",
    },
    {
      number: "3",
      title: "Relatório Técnico",
      description:
        "Relatórios completos com todas as vulnerabilidades identificadas, classificadas por severidade, evidências e passos simples para correção — não integrado à plataforma para resolver em tempo real.",
    },
    {
      number: "4",
      title: "Suporte Após Relatório",
      description:
        "30 dias de suporte técnico após a entrega de Pentest com reuniões de acompanhamento ao vivo e reteste após as correções.",
    },
  ];

  return (
    <section id="processo" className="pt-16 md:pt-24 pb-8 md:pb-12">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Como realizamos o Pentest
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step) => (
            <div
              key={step.number}
              className="bg-card p-6 rounded-lg border border-border hover:border-primary/50 transition-colors relative"
            >
              <div className="absolute -top-4 left-6 w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold text-accent-foreground">
                  {step.number}
                </span>
              </div>
              <div className="mt-8">
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {step.title}
                </h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Process;
