import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import sistemaLdl from "@/assets/sistema-ldl.webp";
import { ArrowRight, MessageSquare } from "lucide-react";
const Platform = () => {
  return <section id="plataforma" className="py-16 md:py-24 bg-[#0f1729]">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column: Image */}
          <div className="flex justify-center">
            <img src={sistemaLdl} alt="LDL Security Platform" className="w-full max-w-2xl rounded-lg shadow-2xl" />
          </div>

          {/* Right Column: Content */}
          <div className="text-center lg:text-left">
            <Badge className="bg-primary/20 text-primary mb-6 inline-block text-sm">
              Acompanhe, corrija e valide cada falha direto do seu painel em tempo real.            
            </Badge>
            
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-8">Plataforma proativa de segurança cibernética!</h2>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="w-full sm:w-auto" asChild>
                <a href="https://wa.me/5551993704573" target="_blank" rel="noopener noreferrer">
                  <ArrowRight className="w-5 h-5" />
                  Faça um orçamento
                </a>
              </Button>
              <Button size="lg" variant="outline" className="w-full sm:w-auto" asChild>
                <a href="https://wa.me/5551993704573" target="_blank" rel="noopener noreferrer">
                  <MessageSquare className="w-5 h-5" />
                  Fale conosco
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default Platform;