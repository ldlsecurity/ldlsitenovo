import { Button } from "@/components/ui/button";
import ctaBg from "@/assets/cta-bg.jpg";
import { MessageSquare } from "lucide-react";
const CTA = () => {
  return <section id="orcamento" className="py-16 md:py-24 bg-[#0f1729]">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="relative rounded-lg p-8 md:p-16 overflow-hidden bg-card border border-border">
          <div className="absolute inset-0 opacity-80" style={{
          backgroundImage: "url(\"/lovable-uploads/77b0d17d-8cbe-4828-a5d7-951b34767346.webp\")",
          backgroundSize: "cover",
          backgroundPosition: "center"
        }}></div>

          <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
                Como realizamos o orçamento?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-xl">
                Entre em contato para uma análise personalizada das necessidades de segurança da sua empresa.
              </p>
              <div className="flex flex-col sm:flex-row items-start gap-4">
                <Button size="lg" className="w-full sm:w-auto" asChild>
                  <a href="https://wa.me/5551993704573?text=Olá!%20Gostaria%20de%20solicitar%20um%20orçamento." target="_blank" rel="noopener noreferrer">
                    <MessageSquare className="w-5 h-5" />
                    Solicitar Orçamento
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default CTA;