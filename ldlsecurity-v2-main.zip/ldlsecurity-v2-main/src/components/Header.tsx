import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link, useLocation, useNavigate } from "react-router-dom";
import logoImage from "@/assets/ldl-logo-full.png";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  
  const scrollToSection = (sectionId: string) => {
    if (location.pathname !== '/') {
      navigate('/', { state: { scrollTo: sectionId } });
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
    setMobileMenuOpen(false);
  };

  return (
    <header className="absolute top-0 left-0 right-0 w-full z-50 py-6">
      <div className="container mx-auto px-6 lg:px-8">
        <nav className="flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <img alt="LDL Security Logo" className="h-10" src={logoImage} />
          </Link>

          <div className="hidden lg:flex items-center space-x-8 text-foreground">
            <Link to="/" className="text-sm font-medium hover:text-primary transition-colors">
              Início
            </Link>
            <Link to="/sobre" className="text-sm font-medium hover:text-primary transition-colors">
              Sobre Nós
            </Link>
            <Link to="/blog" className="text-sm font-medium hover:text-primary transition-colors">
              Notícias
            </Link>
            <button 
              onClick={() => scrollToSection('servicos')} 
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Serviços
            </button>
            <Link to="/certificado" className="text-sm font-medium hover:text-primary transition-colors">
              Certificado
            </Link>
            <button 
              onClick={() => scrollToSection('processo')} 
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Orçamento
            </button>
          </div>

          <Button variant="secondary" className="hidden lg:inline-flex" asChild>
            <a href="https://wa.me/5551993704573?text=Olá!%20Gostaria%20de%20solicitar%20um%20orçamento." target="_blank" rel="noopener noreferrer">
              Faça um orçamento
            </a>
          </Button>

          <button
            className="lg:hidden text-foreground"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>

        {mobileMenuOpen && (
          <div className="lg:hidden mt-6 pb-6 space-y-4 text-foreground">
            <Link
              to="/"
              className="block text-sm font-medium hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Início
            </Link>
            <Link
              to="/sobre"
              className="block text-sm font-medium hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Sobre Nós
            </Link>
            <Link
              to="/blog"
              className="block text-sm font-medium hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Notícias
            </Link>
            <button
              onClick={() => scrollToSection('servicos')}
              className="block text-sm font-medium hover:text-primary transition-colors text-left w-full"
            >
              Serviços
            </button>
            <Link
              to="/certificado"
              className="block text-sm font-medium hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Certificado
            </Link>
            <button
              onClick={() => scrollToSection('processo')}
              className="block text-sm font-medium hover:text-primary transition-colors text-left w-full"
            >
              Orçamento
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
