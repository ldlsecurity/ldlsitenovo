import { useRef } from "react";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";

const Testimonials = () => {
  const autoplayRef = useRef(
    Autoplay({
      delay: 5000,
      stopOnInteraction: true,
      stopOnMouseEnter: false,
    })
  );

  const testimonials = [
    {
      company: "4 Events",
      videoId: "lVHHfIzV6VM",
    },
    {
      company: "Adax Dental",
      videoId: "SeNfFj9SRKM",
    },
    {
      company: "OpenManager",
      videoId: "geV9cZ6UZ88",
    },
    {
      company: "Quero Ingresso",
      videoId: "iJVOnhyMevg",
    },
    {
      company: "Cliente",
      videoId: "Xx8XnFnmEBo",
    },
  ];

  const handleVideoClick = () => {
    if (autoplayRef.current) {
      autoplayRef.current.stop();
    }
  };

  return (
    <section className="py-16 md:py-24 bg-[hsl(var(--bg-navy))]">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Depoimentos reais de problemas reais
          </h2>
          <p className="text-muted-foreground">
            Veja o que nossos clientes têm a dizer sobre nossos serviços
          </p>
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          plugins={[autoplayRef.current]}
          className="w-full"
        >
          <CarouselContent>
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={index} className="md:basis-1/3">
                <div className="bg-card rounded-lg border border-border overflow-hidden">
                  <div className="aspect-video bg-muted relative" onClick={handleVideoClick}>
                    <iframe
                      className="w-full h-full"
                      src={`https://www.youtube.com/embed/${testimonial.videoId}?enablejsapi=1`}
                      title={`Depoimento ${testimonial.company}`}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                  <div className="p-6 text-center">
                    <h3 className="font-bold text-foreground text-lg">
                      {testimonial.company}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-2">
                      Cliente LDL Security
                    </p>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious 
            className="-left-12 bg-primary hover:bg-primary/90 text-primary-foreground border-0 shadow-lg h-14 w-14"
          />
          <CarouselNext 
            className="-right-12 bg-primary hover:bg-primary/90 text-primary-foreground border-0 shadow-lg h-14 w-14"
          />
        </Carousel>
      </div>
    </section>
  );
};

export default Testimonials;
