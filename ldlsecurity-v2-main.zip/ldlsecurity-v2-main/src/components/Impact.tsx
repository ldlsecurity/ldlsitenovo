import { DollarSign, Clock, ShieldAlert } from "lucide-react";
const Impact = () => {
  return <section className="pt-8 md:pt-12 pb-16 md:pb-24">
      <div className="container mx-auto px-6 lg:px-8 text-center">
      <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12">
          Como realizamos o orçamento?
        </h2>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-card p-8 rounded-lg border border-border text-left hover:border-primary/50 transition-colors">
            <DollarSign className="w-10 h-10 text-accent mb-4" />
            <h3 className="text-xl font-bold text-foreground mb-2">
              Orçamento
            </h3>
            <p className="text-muted-foreground">
              Avaliamos o sistema, incluindo quantidade de domínios, camadas de aplicação e infraestrutura, para definir o escopo e a complexidade do teste após envio da proposta comercial.
            </p>
          </div>

          <div className="bg-card p-8 rounded-lg border border-border text-left hover:border-primary/50 transition-colors">
            <Clock className="w-10 h-10 text-accent mb-4" />
            <h3 className="text-xl font-bold text-foreground mb-2">
              Acordo de confidencialidade
            </h3>
            <p className="text-muted-foreground">
              Firmamos um NDA, garantindo a segurança das informações de ambas as partes e o comprometimento com o serviço, prazos e valores.
            </p>
          </div>

          <div className="bg-card p-8 rounded-lg border border-border text-left hover:border-primary/50 transition-colors">
            <ShieldAlert className="w-10 h-10 text-accent mb-4" />
            <h3 className="text-xl font-bold text-foreground mb-2">
              Tempo de entrega
            </h3>
            <p className="text-muted-foreground">
              O prazo varia conforme a complexidade do sistema e é definido na proposta comercial e no contrato.
            </p>
          </div>
        </div>
      </div>
    </section>;
};
export default Impact;