import logoImage from "@/assets/ldl-logo-full.png";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Mail, Phone, Youtube, Linkedin } from "lucide-react";

const Footer = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  const scrollToSection = (sectionId: string) => {
    if (location.pathname !== '/') {
      navigate('/', { state: { scrollTo: sectionId } });
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <footer className="py-16 md:py-24 text-muted-foreground bg-[hsl(var(--bg-navy))]">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="lg:col-span-1">
            <div className="mb-4">
              <img alt="LDL Security Logo" className="h-10" src={logoImage} />
            </div>
            <p className="text-sm mb-6">
              Protegendo empresas brasileiras contra ameaças cibernéticas.
            </p>
            <div className="flex gap-4">
              <a 
                href="https://www.youtube.com/@LDLSecurity" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-foreground transition-colors"
                aria-label="YouTube"
              >
                <Youtube size={20} />
              </a>
              <a 
                href="https://www.linkedin.com/company/ldlsecurity/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-foreground transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          <div>
            <h5 className="font-bold text-foreground mb-4">Links Rápidos</h5>
            <ul className="space-y-2 text-sm">
              <li>
                <Link
                  to="/"
                  className="hover:text-foreground transition-colors"
                >
                  Início
                </Link>
              </li>
              <li>
                <Link
                  to="/sobre"
                  className="hover:text-foreground transition-colors"
                >
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link
                  to="/blog"
                  className="hover:text-foreground transition-colors"
                >
                  Notícias
                </Link>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('servicos')}
                  className="hover:text-foreground transition-colors text-left"
                >
                  Serviços
                </button>
              </li>
              <li>
                <Link
                  to="/certificado"
                  className="hover:text-foreground transition-colors"
                >
                  Certificado
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-foreground mb-4">Suporte</h5>
            <ul className="space-y-3 text-sm">
              <li>
                <a 
                  href="mailto:Suporte@ldlsecurity.com.br"
                  className="hover:text-foreground transition-colors flex items-center gap-2"
                >
                  <Mail size={16} />
                  Suporte@ldlsecurity.com.br
                </a>
              </li>
              <li>
                <a 
                  href="https://wa.me/5551993704573" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-foreground transition-colors flex items-center gap-2"
                >
                  <Phone size={16} />
                  +55 51 99370-4573
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-foreground mb-4">Localização</h5>
            <address className="text-sm not-italic">
              Porto Alegre, Rio Grande do Sul
            </address>
          </div>
        </div>

        <div className="border-t border-border mt-16 pt-8 flex flex-col md:flex-row justify-between items-center text-sm">
          <div className="flex flex-col items-center md:items-start">
            <p>© 2025 LDL Security. Todos os direitos reservados.</p>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 text-xs mt-1">
              <p>CNPJ: 58.552.732/0001-74</p>
              <span className="text-border">|</span>
              <p>Email: suporte@ldlsecurity.com.br</p>
            </div>
          </div>
          <div className="flex gap-4 mt-4 md:mt-0">
            <Link to="/terms" className="hover:text-foreground transition-colors">
              Termos & Condições
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
