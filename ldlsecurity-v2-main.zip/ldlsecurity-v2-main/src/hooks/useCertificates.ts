import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "./use-toast";

export interface Certificate {
  id: string;
  cnpj: string;
  company_name: string;
  validation_key: string;
  document_url: string;
  domains: string[];
  created_at: string;
  updated_at: string;
}

export const useCertificates = () => {
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchCertificates = async () => {
    try {
      const { data, error } = await supabase
        .from("certificates")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setCertificates(data || []);
    } catch (error) {
      console.error("Error fetching certificates:", error);
      toast({
        title: "Erro ao carregar certificados",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  const addCertificate = async (
    cnpj: string,
    companyName: string,
    domains: string[],
    file: File
  ) => {
    try {
      // Generate 9-digit validation key
      const validationKey = Math.floor(100000000 + Math.random() * 900000000).toString();
      
      // Upload file to storage
      const fileExt = file.name.split(".").pop();
      const fileName = `${validationKey}.${fileExt}`;
      const { error: uploadError } = await supabase.storage
        .from("certificates")
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from("certificates")
        .getPublicUrl(fileName);

      // Insert certificate record
      const { data, error } = await supabase
        .from("certificates")
        .insert({
          cnpj,
          company_name: companyName,
          validation_key: validationKey,
          document_url: publicUrl,
          domains,
        })
        .select()
        .single();

      if (error) throw error;

      setCertificates([data, ...certificates]);
      toast({ title: "Certificado criado com sucesso!" });
      return data;
    } catch (error) {
      console.error("Error adding certificate:", error);
      toast({
        title: "Erro ao criar certificado",
        variant: "destructive",
      });
      throw error;
    }
  };

  const updateCertificate = async (
    id: string,
    cnpj: string,
    companyName: string,
    domains: string[],
    file?: File
  ) => {
    try {
      let documentUrl: string | undefined;

      // If new file, upload it
      if (file) {
        const certificate = certificates.find(c => c.id === id);
        if (certificate) {
          // Delete old file
          const oldFileName = certificate.document_url.split("/").pop();
          if (oldFileName) {
            await supabase.storage
              .from("certificates")
              .remove([oldFileName]);
          }
        }

        // Upload new file
        const fileExt = file.name.split(".").pop();
        const fileName = `${certificate?.validation_key || Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from("certificates")
          .upload(fileName, file, { upsert: true });

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from("certificates")
          .getPublicUrl(fileName);
        
        documentUrl = publicUrl;
      }

      // Update certificate record
      const updateData: any = {
        cnpj,
        company_name: companyName,
        domains,
      };
      
      if (documentUrl) {
        updateData.document_url = documentUrl;
      }

      const { data, error } = await supabase
        .from("certificates")
        .update(updateData)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;

      setCertificates(certificates.map(c => c.id === id ? data : c));
      toast({ title: "Certificado atualizado!" });
      return data;
    } catch (error) {
      console.error("Error updating certificate:", error);
      toast({
        title: "Erro ao atualizar certificado",
        variant: "destructive",
      });
      throw error;
    }
  };

  const deleteCertificate = async (id: string) => {
    try {
      const certificate = certificates.find(c => c.id === id);
      
      // Delete file from storage
      if (certificate) {
        const fileName = certificate.document_url.split("/").pop();
        if (fileName) {
          await supabase.storage
            .from("certificates")
            .remove([fileName]);
        }
      }

      // Delete certificate record
      const { error } = await supabase
        .from("certificates")
        .delete()
        .eq("id", id);

      if (error) throw error;

      setCertificates(certificates.filter(c => c.id !== id));
      toast({
        title: "Certificado removido",
        variant: "destructive",
      });
    } catch (error) {
      console.error("Error deleting certificate:", error);
      toast({
        title: "Erro ao remover certificado",
        variant: "destructive",
      });
    }
  };

  const validateCertificate = async (validationKey: string) => {
    try {
      const { data, error } = await supabase
        .from("certificates")
        .select("*")
        .eq("validation_key", validationKey)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error("Error validating certificate:", error);
      return null;
    }
  };

  return {
    certificates,
    loading,
    addCertificate,
    updateCertificate,
    deleteCertificate,
    validateCertificate,
    refreshCertificates: fetchCertificates,
  };
};
