import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "./use-toast";

export interface Category {
  id: string;
  name: string;
  slug: string;
  created_at: string;
}

export const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .order("name", { ascending: true });

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error("Error fetching categories:", error);
      toast({
        title: "Erro ao carregar categorias",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const addCategory = async (name: string, slug: string) => {
    try {
      const { data, error } = await supabase
        .from("categories")
        .insert({ name, slug })
        .select()
        .single();

      if (error) throw error;

      setCategories([...categories, data]);
      toast({ title: "Categoria criada!" });
      return data;
    } catch (error) {
      console.error("Error adding category:", error);
      toast({
        title: "Erro ao criar categoria",
        variant: "destructive",
      });
      throw error;
    }
  };

  const updateCategory = async (id: string, name: string, slug: string) => {
    try {
      const { data, error } = await supabase
        .from("categories")
        .update({ name, slug })
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;

      setCategories(categories.map(c => c.id === id ? data : c));
      toast({ title: "Categoria atualizada!" });
      return data;
    } catch (error) {
      console.error("Error updating category:", error);
      toast({
        title: "Erro ao atualizar categoria",
        variant: "destructive",
      });
      throw error;
    }
  };

  const deleteCategory = async (id: string) => {
    try {
      // Check if category has posts
      const { count } = await supabase
        .from("posts")
        .select("*", { count: "exact", head: true })
        .eq("category_id", id);

      if (count && count > 0) {
        toast({
          title: "Não é possível excluir",
          description: "Esta categoria possui posts vinculados",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from("categories")
        .delete()
        .eq("id", id);

      if (error) throw error;

      setCategories(categories.filter(c => c.id !== id));
      toast({
        title: "Categoria removida",
        variant: "destructive",
      });
    } catch (error) {
      console.error("Error deleting category:", error);
      toast({
        title: "Erro ao remover categoria",
        variant: "destructive",
      });
    }
  };

  return {
    categories,
    loading,
    addCategory,
    updateCategory,
    deleteCategory,
    refreshCategories: fetchCategories,
  };
};
