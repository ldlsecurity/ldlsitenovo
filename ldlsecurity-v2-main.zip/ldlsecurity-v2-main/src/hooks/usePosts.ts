import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "./use-toast";

export interface Post {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  featured_image: string | null;
  category_id: string | null;
  author: string;
  publish_date: string;
  read_time: string | null;
  meta_title: string | null;
  meta_description: string | null;
  published: boolean;
  created_at: string;
  updated_at: string;
  categories?: {
    id: string;
    name: string;
    slug: string;
  };
}

export const usePosts = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .select(`
          *,
          categories (
            id,
            name,
            slug
          )
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error("Error fetching posts:", error);
      toast({
        title: "Erro ao carregar posts",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const addPost = async (postData: Omit<Post, "id" | "created_at" | "updated_at" | "categories">) => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .insert(postData)
        .select(`
          *,
          categories (
            id,
            name,
            slug
          )
        `)
        .single();

      if (error) throw error;

      setPosts([data, ...posts]);
      toast({ title: "Post criado com sucesso!" });
      return data;
    } catch (error) {
      console.error("Error adding post:", error);
      toast({
        title: "Erro ao criar post",
        variant: "destructive",
      });
      throw error;
    }
  };

  const updatePost = async (id: string, postData: Partial<Post>) => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .update(postData)
        .eq("id", id)
        .select(`
          *,
          categories (
            id,
            name,
            slug
          )
        `)
        .single();

      if (error) throw error;

      setPosts(posts.map(p => p.id === id ? data : p));
      toast({ title: "Post atualizado!" });
      return data;
    } catch (error) {
      console.error("Error updating post:", error);
      toast({
        title: "Erro ao atualizar post",
        variant: "destructive",
      });
      throw error;
    }
  };

  const deletePost = async (id: string) => {
    try {
      const post = posts.find(p => p.id === id);
      
      // Delete featured image from storage if exists
      if (post?.featured_image) {
        const fileName = post.featured_image.split("/").pop();
        if (fileName) {
          await supabase.storage
            .from("blog-images")
            .remove([fileName]);
        }
      }

      const { error } = await supabase
        .from("posts")
        .delete()
        .eq("id", id);

      if (error) throw error;

      setPosts(posts.filter(p => p.id !== id));
      toast({
        title: "Post removido",
        variant: "destructive",
      });
    } catch (error) {
      console.error("Error deleting post:", error);
      toast({
        title: "Erro ao remover post",
        variant: "destructive",
      });
    }
  };

  const getPostBySlug = async (slug: string) => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .select(`
          *,
          categories (
            id,
            name,
            slug
          )
        `)
        .eq("slug", slug)
        .eq("published", true)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error("Error fetching post:", error);
      return null;
    }
  };

  const getPostBySlugForEdit = async (slug: string) => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .select(`
          *,
          categories (
            id,
            name,
            slug
          )
        `)
        .eq("slug", slug)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error("Error fetching post for edit:", error);
      return null;
    }
  };

  return {
    posts,
    loading,
    addPost,
    updatePost,
    deletePost,
    getPostBySlug,
    getPostBySlugForEdit,
    refreshPosts: fetchPosts,
  };
};
