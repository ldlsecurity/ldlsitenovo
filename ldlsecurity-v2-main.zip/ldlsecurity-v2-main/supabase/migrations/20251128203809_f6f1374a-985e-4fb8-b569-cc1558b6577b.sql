-- Add domains column to certificates table
ALTER TABLE public.certificates 
ADD COLUMN domains text[] DEFAULT '{}';

-- Add comment
COMMENT ON COLUMN public.certificates.domains IS 'Array of domains associated with this certificate';